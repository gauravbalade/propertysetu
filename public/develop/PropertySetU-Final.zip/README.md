# PropertySetu — Academic Property Application Workflow

> **Start here:** open [START_HERE.md](START_HERE.md) first. It directs you to the correct folders for Spring Tools, VS Code and MySQL Workbench.

## Overview

PropertySetu is a student-developed full-stack property application workflow. It demonstrates the layered Spring Boot architecture taught through the Shopify classroom project while applying it to a distinct, non-e-commerce domain.

- Applicant and role management
- Owner, property, and location records
- Document uploads and application review
- Application lifecycle and officer decisions
- Razorpay Test Mode payment workflow
- JWT authentication and role-based authorization
- React + Vite user interface and MySQL-compatible persistence

> **Academic project notice:** This is a learning/demo platform, not an official government property-registration portal. It does not perform official registration or provide legal approval. Keep payments in Razorpay Test Mode and use synthetic documents.

## Architecture

```text
PropertySetu/
├── backend/
│   ├── pom.xml
│   └── src/main/java/com/gaurav/property/
│       ├── config/       # Spring Security, CORS and app configuration
│       ├── controller/   # REST API endpoints
│       ├── dto/          # Request/response transfer objects
│       ├── entity/       # JPA entities and enums
│       ├── repository/   # Spring Data JPA interfaces
│       ├── security/     # JWT services and authentication helpers
│       └── service/      # Business rules, transactions and gateway calls
├── frontend/             # React + Vite application
├── database/             # schema notes and local setup
├── documentation/        # API, testing, deployment, IDE and design docs
│   ├── IDE_WORKFLOW_WINDOWS.md
│   └── research/          # full advanced engineering specification + implementation ledger
├── presentation/         # demo script and project report
└── demo/uploads/          # local demo upload directory
```

## Classroom concepts mapped to PropertySetu

| Classroom Spring concept | PropertySetu equivalent |
|---|---|
| ShopifyApplication | PropertyRegistrationBackendApplication |
| User / Customer | UserAccount / Owner |
| Product | Property |
| Category / SubCategory | Property type / application purpose |
| Cart / Order workflow | RegistrationApplication workflow |
| OrderItem | ApplicationDocument / application-to-property relationship |
| Vendor | PropertyOwner |
| Product/Category repositories | Property, Owner, Location and Application repositories |
| Services | PropertyService, ApplicationService, PaymentService, DocumentService |
| Controllers | REST controllers for property, application, document, auth, verification and payment |
| DTOs | Validated API request and response types |
| Security configuration + JWT | Stateless token authentication and role-based access |
| PaymentController / PaymentService | Razorpay Test Mode order creation and server-side verification |
| Specifications/search | Application and property filtering/search where supported |
| Response wrapper | Consistent REST error/success responses where implemented |

This is a conceptual mapping, not a claim that every classroom class has a one-to-one equivalent. PropertySetu models property records and review workflows rather than products, shopping carts, inventory or e-commerce orders.

## Domain model and relationships

Core domain records include:

1. **UserAccount** — authenticated identity and role
2. **Owner** — owner profile belonging to an applicant
3. **Property** — property information maintained by an owner
4. **Location** — address and jurisdiction details for a property
5. **RegistrationApplication** — application lifecycle, owner, property and purpose
6. **Document** — metadata and safe storage reference for supporting files
7. **Verification** — assigned officer decision, status, timestamp and remarks
8. **Payment** — gateway order/payment references and server-confirmed verification state
9. **Assignment** — administrator assignment/reassignment history for review ownership

Simplified relationship view:

```text
UserAccount (Applicant)
   └── Owner
        └── Property ─── Location
             └── RegistrationApplication ─── assigned Officer (UserAccount)
                    ├── Document versions
                    ├── Payment
                    ├── Verification (assigned Officer)
                    └── Audit events
```

Actual cardinality follows the JPA annotations in the source.

## Main user journeys

### Applicant
1. Register and authenticate.
2. Create or update owner details.
3. Add a property and location.
4. Create a draft application and upload supporting documents.
5. Submit the application.
6. Create a Razorpay Test Mode order and complete hosted Checkout.
7. View payment and application status.

### Administrator
1. Sign in with a privately provisioned ADMIN account.
2. Create and deactivate Officer accounts.
3. Inspect the full application queue and assign/reassign eligible paid cases.
4. Review application status and audit history; administrators do not perform officer verification.

### Assigned Officer
1. Sign in with an OFFICER account.
2. View only applications assigned to that officer.
3. Open protected documents and mark the latest document versions under review, verified, or rejected with a correction request.
4. Complete or reject the application with remarks after payment and required-document checks pass.
5. Review the audit history for the assigned case.

## Application lifecycle

```text
DRAFT → SUBMITTED → PAYMENT_PENDING → PAID → UNDER_VERIFICATION
                                                   ├── COMPLETED
                                                   ├── REJECTED
                                                   └── NEEDS_CORRECTION
                                                           ↓
                                                       RESUBMITTED
                                                           ↓
                                                   UNDER_VERIFICATION
```

The backend should enforce legal state transitions on the server; the frontend is not trusted to determine payment success or officer authorization.

## Payment architecture

The academic demo uses Razorpay Test Mode when server-side credentials are configured.

1. The backend creates/reuses an order using an amount derived from server-side application rules.
2. The frontend receives the public Key ID and order ID.
3. Checkout collects payment details on the gateway-hosted interface.
4. The backend validates the returned signature and confirms payment/order amount and status with the provider.
5. Webhook reconciliation can update payment state after validating the webhook signature.

Never commit gateway secrets, database credentials, JWT signing keys, SMS-provider tokens, or uploaded personal documents. Never represent a browser-only success message as proof of payment. Keep the displayed fee clearly identified as an academic test fee.

## Technology stack

- Java 17
- Spring Boot 4.x
- Spring Web MVC, Spring Data JPA, Spring Security and Bean Validation
- MySQL locally; compatible MySQL service may be used for the hosted demo
- JWT bearer authentication and BCrypt password hashing
- Razorpay Java SDK (Test Mode)
- React 19, Vite and responsive CSS
- Maven wrapper for reproducible backend commands

## Local setup

Start with [Windows IDE Workflow](documentation/IDE_WORKFLOW_WINDOWS.md) for exactly what to import in Spring Tools and what to open in VS Code. For environment setup and commands, see [Local Setup](documentation/LOCAL_SETUP_WINDOWS.md). The full [Advanced Product & Engineering Specification](documentation/research/ADVANCED_PRODUCT_AND_ENGINEERING_SPEC.md) and its [implementation status after this pass](documentation/research/IMPLEMENTATION_STATUS_AFTER_FINAL_PASS.md) are included under documentation/research/.


### 1. Create the database

In MySQL Workbench:

```sql
CREATE DATABASE property_registration_db;
```

The recommended first run is the Windows launcher in the repository root: double-click `START_PROPERTYSETU.bat`. Before launching, create the MySQL database and copy `backend/.env.example` to `backend/.env.local`, then enter your local DB credentials. The launcher generates a random local JWT secret when none is supplied. The optional admin bootstrap creates an administrator only when all three `ADMIN_BOOTSTRAP_*` values are provided and that account does not already exist. Remove the bootstrap password after first startup. Never store real values in Git.

### 2. Run the backend (PowerShell)

```powershell
cd backend
.\mvnw.cmd spring-boot:run
```

The default API port is `8080`.

### 3. Run the frontend

```powershell
cd frontend
npm ci
npm run dev
```

Open the Vite URL printed by the command (normally `http://localhost:5173`). Set `VITE_API_URL` to the backend URL if needed.

## Research and implementation baseline

The project includes the full Advanced Product & Engineering Specification dated 1 November 2026. The research-to-implementation ledger distinguishes current code, partially verified workflows, future target capabilities and checks not yet run. Do not present roadmap ideas such as OCR/AI, official registry integrations, property lifecycle events or production SLA management as already implemented.

## Verification checklist

- [ ] MySQL service is running and the database exists.
- [ ] Backend starts without dependency or datasource errors.
- [ ] Frontend development server starts and can reach the API.
- [ ] Registration and login work with test accounts.
- [ ] Protected endpoints reject missing/invalid bearer tokens.
- [ ] Applicants cannot inspect or modify another applicant's records or download their files.
- [ ] Admin can assign/reassign paid review-stage cases to active OFFICER accounts.
- [ ] Officers can list and open only their assigned cases.
- [ ] Admin inspection does not permit admin document decisions; only the assigned Officer can review/verify.
- [ ] Document upload validates type/size/signature and stores private files outside the public frontend.
- [ ] Replacing a document creates a new version and preserves superseded history.
- [ ] Correction requests allow the applicant to replace rejected documents and resubmit without a second application fee.
- [ ] Invalid application-state transitions are rejected.
- [ ] Verification requires a captured, signature-confirmed Razorpay Test Mode payment and the latest required document versions.
- [ ] Payment amount, currency, order ID and signatures are verified server-side in Test Mode.
- [ ] Secrets and private uploads are absent from Git history.
- [ ] Frontend production build and backend test suite complete successfully.

See `documentation/API_GUIDE.md`, `documentation/DATABASE.md`, `documentation/LOCAL_SETUP_WINDOWS.md` and `documentation/TESTING_CHECKLIST.md` for setup, API and verification details.

## Future improvements

- Use Flyway/Liquibase migrations and validate the deployment schema.
- Add fine-grained authorization tests and concurrency protections for review.
- Add malware scanning, private object storage, retention controls and authenticated downloads.
- Add throttling, structured audit logging, monitoring, backups and secret management.
- Add integration tests for payment webhooks and failure/retry states.

## License

See [LICENSE](LICENSE).


## New classroom-style Java project

A separate Spring Boot + MySQL starter project following the layered conventions demonstrated in the Shopify classroom code is available in [`PropertyDesk/`](PropertyDesk/README.md). It manages property owners, property records, locations, and visit requests; it is separate from the existing full-stack PropertySetu application.
