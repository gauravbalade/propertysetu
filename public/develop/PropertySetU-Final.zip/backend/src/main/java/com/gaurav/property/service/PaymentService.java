package com.gaurav.property.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gaurav.property.dto.ApplicationResponse;
import com.gaurav.property.dto.PaymentOrderRequest;
import com.gaurav.property.dto.PaymentResponse;
import com.gaurav.property.dto.PaymentVerificationRequest;
import com.gaurav.property.entity.Payment;
import com.gaurav.property.entity.RegistrationApplication;
import com.gaurav.property.enums.ApplicationStatus;
import com.gaurav.property.enums.PaymentStatus;
import com.gaurav.property.repository.PaymentRepository;
import com.gaurav.property.repository.RegistrationApplicationRepository;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import com.razorpay.Order;

@Service
public class PaymentService {

    private static final BigDecimal PAYMENT_AMOUNT = BigDecimal.valueOf(500);

    private final PaymentRepository paymentRepository;
    private final RegistrationApplicationRepository applicationRepository;
    private final AuthorizationService authorizationService;
    private final AuditService auditService;
    private final NotificationService notificationService;

    @Value("${RAZORPAY_KEY_ID:}")
    private String razorpayKeyId;

    @Value("${RAZORPAY_KEY_SECRET:}")
    private String razorpayKeySecret;

    @Value("${RAZORPAY_WEBHOOK_SECRET:}")
    private String razorpayWebhookSecret;

    public PaymentService(PaymentRepository paymentRepository,
            RegistrationApplicationRepository applicationRepository,
            AuthorizationService authorizationService,
            AuditService auditService,
            NotificationService notificationService) {
        this.paymentRepository = paymentRepository;
        this.applicationRepository = applicationRepository;
        this.authorizationService = authorizationService;
        this.auditService = auditService;
        this.notificationService = notificationService;
    }

    @Transactional
    public PaymentResponse createPaymentOrder(PaymentOrderRequest request) {
        RegistrationApplication application = applicationRepository.findById(request.getApplicationId())
                .orElseThrow(() -> new RuntimeException("Application not found"));
        authorizationService.requireOwner(application.getUserAccount());

        if (application.getStatus() == ApplicationStatus.PAID
                || application.getStatus() == ApplicationStatus.UNDER_VERIFICATION
                || application.getStatus() == ApplicationStatus.VERIFIED
                || application.getStatus() == ApplicationStatus.COMPLETED) {
            return paymentRepository.findByApplicationId(application.getId()).stream()
                    .filter(existing -> existing.getPaymentStatus() == PaymentStatus.SUCCESS)
                    .findFirst()
                    .map(this::toResponse)
                    .orElseThrow(() -> new RuntimeException("Payment is already completed"));
        }

        if (application.getStatus() != ApplicationStatus.SUBMITTED
                && application.getStatus() != ApplicationStatus.PAYMENT_PENDING) {
            throw new RuntimeException("Payment is available only for submitted applications");
        }

        if (request.getAmount() == null || request.getAmount().compareTo(PAYMENT_AMOUNT) != 0) {
            throw new RuntimeException("The payment amount is fixed at ₹500.00 for this academic demonstration.");
        }

        requireRazorpayConfiguration();

        if (application.getStatus() == ApplicationStatus.PAYMENT_PENDING) {
            Payment pending = paymentRepository.findByApplicationId(application.getId()).stream()
                    .filter(existing -> existing.getPaymentStatus() == PaymentStatus.PENDING)
                    .filter(existing -> "RAZORPAY".equalsIgnoreCase(existing.getGatewayReference()))
                    .findFirst()
                    .orElse(null);
            if (pending != null) {
                return toResponse(pending);
            }
        }

        try {
            RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", 50000);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", application.getApplicationNumber());

            JSONObject notes = new JSONObject();
            notes.put("application_id", String.valueOf(application.getId()));
            notes.put("application_number", application.getApplicationNumber());
            orderRequest.put("notes", notes);

            Order order = client.orders.create(orderRequest);
            String orderId = order.get("id");

            Payment payment = new Payment();
            payment.setApplication(application);
            payment.setGatewayOrderId(orderId);
            payment.setAmount(PAYMENT_AMOUNT);
            payment.setPaymentDate(LocalDateTime.now());
            payment.setPaymentStatus(PaymentStatus.PENDING);
            payment.setSignatureVerified(false);
            payment.setGatewayReference("RAZORPAY");

            application.setStatus(ApplicationStatus.PAYMENT_PENDING);
            applicationRepository.save(application);
            Payment saved = paymentRepository.save(payment);

            auditService.record("RAZORPAY_ORDER_CREATED", "APPLICATION", application.getId(),
                    authorizationService.currentUser(), "Razorpay test order " + orderId);

            return toResponse(saved);
        } catch (RazorpayException ex) {
            throw new RuntimeException("Razorpay could not create the payment order. Please try again.");
        }
    }

    @Transactional(readOnly = true)
    public PaymentResponse getLatestPayment(Long applicationId) {
        RegistrationApplication application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));
        authorizationService.requireCanReadApplication(application);

        return paymentRepository.findByApplicationId(applicationId).stream()
                .max((left, right) -> {
                    LocalDateTime leftDate = left.getPaymentDate();
                    LocalDateTime rightDate = right.getPaymentDate();
                    if (leftDate == null && rightDate == null) return 0;
                    if (leftDate == null) return -1;
                    if (rightDate == null) return 1;
                    return leftDate.compareTo(rightDate);
                })
                .map(this::toResponse)
                .orElse(null);
    }

    @Transactional
    public PaymentResponse verifyPayment(PaymentVerificationRequest request) {
        Payment payment = paymentRepository.findById(request.getPaymentId())
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        RegistrationApplication application = payment.getApplication();
        authorizationService.requireOwner(application.getUserAccount());

        if (!"RAZORPAY".equalsIgnoreCase(payment.getGatewayReference())) {
            throw new RuntimeException("This payment record is not a Razorpay order.");
        }

        if (payment.getPaymentStatus() == PaymentStatus.SUCCESS) {
            return toResponse(payment);
        }

        if (!java.util.Objects.equals(payment.getGatewayOrderId(), request.getRazorpayOrderId())) {
            throw new RuntimeException("Payment order mismatch.");
        }

        requireRazorpayConfiguration();

        try {
            JSONObject attributes = new JSONObject();
            attributes.put("razorpay_order_id", payment.getGatewayOrderId());
            attributes.put("razorpay_payment_id", request.getRazorpayPaymentId());
            attributes.put("razorpay_signature", request.getRazorpaySignature());

            if (!Utils.verifyPaymentSignature(attributes, razorpayKeySecret)) {
                throw new RuntimeException("Razorpay payment signature could not be verified.");
            }

            RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
            com.razorpay.Payment razorpayPayment = client.payments.fetch(request.getRazorpayPaymentId());
            String status = String.valueOf(razorpayPayment.get("status"));
            String capturedOrderId = String.valueOf(razorpayPayment.get("order_id"));
            String currency = String.valueOf(razorpayPayment.get("currency"));
            if (!"captured".equalsIgnoreCase(status)) {
                throw new RuntimeException("Razorpay payment is not captured yet.");
            }
            if (!java.util.Objects.equals(payment.getGatewayOrderId(), capturedOrderId)) {
                throw new RuntimeException("The captured payment belongs to a different Razorpay order.");
            }
            if (!"INR".equalsIgnoreCase(currency)) {
                throw new RuntimeException("The captured payment currency does not match INR.");
            }

            Object amountValue = razorpayPayment.get("amount");
            long capturedAmount = Long.parseLong(String.valueOf(amountValue));
            if (capturedAmount != 50000L) {
                throw new RuntimeException("The captured payment amount does not match the application fee.");
            }

            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            payment.setSignatureVerified(true);
            payment.setGatewayPaymentId(request.getRazorpayPaymentId());
            payment.setPaymentDate(LocalDateTime.now());
            application.setStatus(ApplicationStatus.PAID);

            applicationRepository.save(application);
            Payment saved = paymentRepository.save(payment);

            auditService.record("RAZORPAY_PAYMENT_VERIFIED", "PAYMENT", payment.getId(),
                    authorizationService.currentUser(), "Razorpay signature and captured amount verified");
            auditService.record("PAYMENT_COMPLETED", "APPLICATION", application.getId(),
                    authorizationService.currentUser(), "Razorpay test payment completed");

            notificationService.sendApplicationStatus(
                    application.getUserAccount().getEmail(),
                    application.getApplicationNumber(),
                    application.getProperty().getPropertyNumber(),
                    application.getStatus().name(),
                    "Your test-mode payment was verified. The application can now move through officer review.");
            
            return toResponse(saved);
        } catch (RazorpayException ex) {
            throw new RuntimeException("Unable to confirm the Razorpay payment. Please try again.");
        }
    }

    @Transactional
    public PaymentResponse reconcilePayment(Long paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        RegistrationApplication application = payment.getApplication();
        authorizationService.requireOwner(application.getUserAccount());

        if (!"RAZORPAY".equalsIgnoreCase(payment.getGatewayReference())) {
            throw new RuntimeException("This payment record is not a Razorpay order.");
        }

        if (payment.getPaymentStatus() == PaymentStatus.SUCCESS) {
            return toResponse(payment);
        }

        requireRazorpayConfiguration();

        try {
            RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
            List<com.razorpay.Payment> payments = client.orders.fetchPayments(payment.getGatewayOrderId());

            for (com.razorpay.Payment razorpayPayment : payments) {
                String orderId = String.valueOf(razorpayPayment.get("order_id"));
                String status = String.valueOf(razorpayPayment.get("status"));
                String currency = String.valueOf(razorpayPayment.get("currency"));
                long amount = Long.parseLong(String.valueOf(razorpayPayment.get("amount")));

                if (java.util.Objects.equals(payment.getGatewayOrderId(), orderId)
                        && "captured".equalsIgnoreCase(status)
                        && "INR".equalsIgnoreCase(currency)
                        && amount == 50000L) {
                    payment.setPaymentStatus(PaymentStatus.SUCCESS);
                    payment.setSignatureVerified(true);
                    payment.setGatewayPaymentId(String.valueOf(razorpayPayment.get("id")));
                    payment.setPaymentDate(LocalDateTime.now());

                    application.setStatus(ApplicationStatus.PAID);
                    applicationRepository.save(application);
                    Payment saved = paymentRepository.save(payment);

                    auditService.record("RAZORPAY_PAYMENT_RECONCILED", "PAYMENT", payment.getId(),
                            authorizationService.currentUser(),
                            "Captured Razorpay payment reconciled from the order");

                    auditService.record("PAYMENT_COMPLETED", "APPLICATION", application.getId(),
                            authorizationService.currentUser(),
                            "Payment completion confirmed by Razorpay order reconciliation");

                    notificationService.sendApplicationStatus(
                            application.getUserAccount().getEmail(),
                            application.getApplicationNumber(),
                            application.getProperty().getPropertyNumber(),
                            application.getStatus().name(),
                            "Your test-mode Razorpay payment was confirmed and reconciled successfully.");

                    return toResponse(saved);
                }
            }

            return toResponse(payment);
        } catch (RazorpayException ex) {
            throw new RuntimeException("Unable to reconcile the Razorpay payment. Please try again.");
        }
    }

    @Transactional
    public void handleRazorpayWebhook(String payload, String signature) {
        if (signature == null || signature.isBlank()) {
            throw new RuntimeException("Missing Razorpay webhook signature.");
        }

        String webhookSecret = razorpayWebhookSecret;
        if (webhookSecret == null || webhookSecret.isBlank()) {
            throw new RuntimeException("Razorpay webhook verification is not configured.");
        }

        try {
            if (!Utils.verifyWebhookSignature(payload, signature, webhookSecret)) {
                throw new RuntimeException("Invalid Razorpay webhook signature.");
            }

            JSONObject body = new JSONObject(payload);
            String event = body.optString("event");

            // Only a signed payment.captured event is accepted as authoritative.
            // An order.paid payload contains an order ID, not necessarily a payment ID.
            if (!"payment.captured".equals(event) || !body.has("payload")) {
                return;
            }
            JSONObject paymentPayload = body.getJSONObject("payload").optJSONObject("payment");
            JSONObject entity = paymentPayload == null ? null : paymentPayload.optJSONObject("entity");
            if (entity == null) {
                return;
            }

            String orderId = entity.optString("order_id");
            String paymentId = entity.optString("id");
            if (orderId.isBlank() || paymentId.isBlank()) {
                return;
            }

            Payment payment = paymentRepository.findByGatewayOrderId(orderId).orElse(null);
            if (payment == null || payment.getPaymentStatus() == PaymentStatus.SUCCESS) {
                return; // duplicate webhook deliveries are idempotent
            }

            long amount = entity.optLong("amount", 0);
            String currency = entity.optString("currency", "INR");
            if (amount != 50000L || !"INR".equalsIgnoreCase(currency)) {
                auditService.record("RAZORPAY_WEBHOOK_REJECTED", "PAYMENT", payment.getId(),
                        null, "Webhook amount or currency did not match the application fee");
                return;
            }

            if (!"captured".equalsIgnoreCase(entity.optString("status"))) {
                return;
            }

            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            payment.setSignatureVerified(true);
            payment.setGatewayPaymentId(paymentId);
            payment.setPaymentDate(LocalDateTime.now());

            RegistrationApplication application = payment.getApplication();
            application.setStatus(ApplicationStatus.PAID);
            applicationRepository.save(application);
            paymentRepository.save(payment);

            auditService.record("RAZORPAY_WEBHOOK_CONFIRMED", "PAYMENT", payment.getId(),
                    null, "Razorpay webhook confirmed captured payment");
            auditService.record("PAYMENT_COMPLETED", "APPLICATION", application.getId(),
                    null, "Payment completion confirmed by Razorpay webhook");

            notificationService.sendApplicationStatus(
                    application.getUserAccount().getEmail(),
                    application.getApplicationNumber(),
                    application.getProperty().getPropertyNumber(),
                    application.getStatus().name(),
                    "Your Razorpay payment was confirmed by the server webhook. No further payment action is required.");
        } catch (RazorpayException ex) {
            throw new RuntimeException("Unable to verify Razorpay webhook signature.");
        }
    }

    private void requireRazorpayConfiguration() {
        if (razorpayKeyId == null || razorpayKeyId.isBlank()
                || razorpayKeySecret == null || razorpayKeySecret.isBlank()) {
            throw new RuntimeException(
                    "Razorpay test credentials are not configured on the server yet.");
        }

        // PropertySetu is an academic demonstration and must never create a live
        // payment order. Enforce Razorpay Test Mode at the server boundary so a
        // production misconfiguration cannot silently turn this workflow into a
        // real-money payment flow.
        if (!razorpayKeyId.startsWith("rzp_test_")) {
            throw new RuntimeException(
                    "PropertySetu is locked to Razorpay Test Mode. Configure an rzp_test_ key only.");
        }
    }

    private PaymentResponse toResponse(Payment payment) {
        RegistrationApplication application = payment.getApplication();
        ApplicationResponse applicationResponse = new ApplicationResponse(
                application.getId(),
                application.getApplicationNumber(),
                application.getUserAccount().getId(),
                application.getUserAccount().getUsername(),
                application.getUserAccount().getEmail(),
                application.getProperty().getId(),
                application.getProperty().getPropertyNumber(),
                application.getPurpose(),
                application.getApplicationDate(),
                application.getStatus(),
                application.getCreatedAt(),
                application.getAssignedOfficer() == null ? null : application.getAssignedOfficer().getId(),
                application.getAssignedOfficer() == null ? null : application.getAssignedOfficer().getUsername(),
                application.getAssignedAt());

        return new PaymentResponse(
                payment.getId(),
                applicationResponse,
                payment.getGatewayOrderId(),
                payment.getGatewayPaymentId(),
                payment.getAmount(),
                payment.getPaymentDate(),
                payment.getPaymentStatus(),
                payment.getSignatureVerified(),
                payment.getGatewayReference(),
                razorpayKeyId,
                "INR");
    }
}