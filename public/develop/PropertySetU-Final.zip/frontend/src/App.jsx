import { useEffect, useState } from "react";
import { Analytics } from "@vercel/analytics/react";
import "./App.css";

const configuredApiUrl = import.meta.env.VITE_API_URL?.trim();

const MSG91_WIDGET_ID = import.meta.env.VITE_MSG91_WIDGET_ID?.trim() || "";
const MSG91_WIDGET_TOKEN = import.meta.env.VITE_MSG91_WIDGET_TOKEN?.trim() || "";
// MSG91 is retained for password recovery; applicant onboarding does not require OTP.

const API = configuredApiUrl?.startsWith("http://") ||
  configuredApiUrl?.startsWith("https://")
  ? configuredApiUrl.replace(/\/+$/, "")
  : import.meta.env.DEV
    ? "http://localhost:8080"
    : "https://propertysetu-backend.onrender.com";

function App() {
  const [step, setStep] = useState("home");
  const [showAbout, setShowAbout] = useState(false);
  const [loginPasswordVisible, setLoginPasswordVisible] = useState(false);
  const [purposeType, setPurposeType] = useState("");
  const [validationErrors, setValidationErrors] = useState([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);
  const [owner, setOwner] = useState(null);
  const [property, setProperty] = useState(null);
  const [application, setApplication] = useState(null);
  const [payment, setPayment] = useState(null);
  const [paymentDemoAcknowledged, setPaymentDemoAcknowledged] = useState(false);
  const [properties, setProperties] = useState([]);
  const [officerMode, setOfficerMode] = useState(false);
  const [applications, setApplications] = useState([]);
  const [applicantApplications, setApplicantApplications] = useState([]);
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [auditEvents, setAuditEvents] = useState([]);
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [applicationSearch, setApplicationSearch] = useState("");
  const [applicationSort, setApplicationSort] = useState("NEWEST");
  const [applicationLookup, setApplicationLookup] = useState("");
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [paymentHistoryLoading, setPaymentHistoryLoading] = useState(false);
  const [workspaceLoading, setWorkspaceLoading] = useState(false);
  const [adminUsers, setAdminUsers] = useState([]);
  const [adminUsersLoading, setAdminUsersLoading] = useState(false);
  const [adminUserForm, setAdminUserForm] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
    role: "OFFICER"
  });
  const [assignmentForm, setAssignmentForm] = useState({
    officerId: "",
    reason: "Initial officer assignment"
  });
  const [remarks, setRemarks] = useState(
    "Payment confirmed and all submitted documents were checked successfully."
  );

  const [loginForm, setLoginForm] = useState({
    username: "",
    password: ""
  });

  const [registerForm, setRegisterForm] = useState({
    username: "",
    password: "",
    email: "",
    phone: ""
  });

  // Registration-only UI state. These stay in the frontend and do not change the backend API.
  const [registerPasswordError, setRegisterPasswordError] = useState("");
  const [registerPasswordVisible, setRegisterPasswordVisible] = useState(false);
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState("");
  const [registerConfirmPasswordVisible, setRegisterConfirmPasswordVisible] = useState(false);

  const [ownerForm, setOwnerForm] = useState({
    name: "",
    address: "",
    phone: "",
    identityNumber: ""
  });

  const [propertyForm, setPropertyForm] = useState({
    propertyNumber: "",
    propertyType: "",
    area: "",
    description: ""
  });
  const [editingPropertyId, setEditingPropertyId] = useState(null);

  const [locationForm, setLocationForm] = useState({
    address: "",
    city: "",
    district: "",
    state: "",
    pincode: ""
  });

  const [purpose, setPurpose] = useState("");
  const [documentType, setDocumentType] = useState("IDENTITY_PROOF");
  const [file, setFile] = useState(null);
  const [uploadedDocuments, setUploadedDocuments] = useState([]);
  const [submissionAcknowledged, setSubmissionAcknowledged] = useState(false);
  const [busy, setBusy] = useState(false);
  const [backendStatus, setBackendStatus] = useState("checking");
  const [verificationUsername] = useState("");
  const [verificationEmail] = useState("");
  const [verificationPhone] = useState("");
  const [verificationCodes, setVerificationCodes] = useState({ EMAIL: "", PHONE: "" });
  const [msg91ReqIds, setMsg91ReqIds] = useState({ EMAIL: "", PHONE: "" });
  const [demoOtpCodes, setDemoOtpCodes] = useState({ EMAIL: "", PHONE: "", RESET: "" });
  const [verificationState, setVerificationState] = useState({ EMAIL: false, PHONE: false });
  const [otpCooldowns, setOtpCooldowns] = useState({ EMAIL: 0, PHONE: 0 });
  const [forgotEmail, setForgotEmail] = useState("");
  const [resetCode, setResetCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [resetReqId, setResetReqId] = useState("");
  const [resetAccessToken, setResetAccessToken] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function wakeBackend() {
      setBackendStatus("checking");
      try {
        const response = await fetch(`${API}/api/health`, {
          method: "GET",
          cache: "no-store"
        });
        if (!response.ok) throw new Error("Backend health check failed");
        if (!cancelled) setBackendStatus("online");
      } catch {
        if (!cancelled) setBackendStatus("unavailable");
      }
    }

    void wakeBackend();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) return undefined;
    if (typeof window !== "undefined" && typeof window.initSendOTP === "function") return undefined;

    const existing = document.querySelector('script[src="https://verify.msg91.com/otp-provider.js"]');
    const script = existing || document.createElement("script");
    script.src = "https://verify.msg91.com/otp-provider.js";
    script.async = true;

    if (!existing) document.body.appendChild(script);
    return undefined;
  }, []);

  useEffect(() => {
    const active = Object.values(otpCooldowns).some(value => value > 0);
    if (!active) return undefined;

    const timer = window.setInterval(() => {
      setOtpCooldowns(previous => ({
        EMAIL: Math.max(0, previous.EMAIL - 1),
        PHONE: Math.max(0, previous.PHONE - 1)
      }));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [otpCooldowns]);

  const requiredDocumentTypes = ["IDENTITY_PROOF", "ADDRESS_PROOF", "PROPERTY_DOCUMENT"];
  const latestDocumentForType = type => uploadedDocuments
    .filter(document => document.documentType === type)
    .sort((left, right) => (right.versionNumber || 1) - (left.versionNumber || 1))[0] || null;
  const readyDocumentTypesCount = requiredDocumentTypes.filter(type => {
    const latest = latestDocumentForType(type);
    return Boolean(latest && latest.status !== "REJECTED" && latest.status !== "SUPERSEDED");
  }).length;
  const hasRequiredDocuments = readyDocumentTypesCount === requiredDocumentTypes.length;

  async function request(url, options = {}) {
    const token = user?.token || sessionStorage.getItem("property_registration_token");
    const isFormData = options.body instanceof FormData;
    const headers = {
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    };

    let response;

    const method = String(options.method || "GET").toUpperCase();
    const retryableRequest = ["GET", "HEAD", "OPTIONS"].includes(method);
    const maxAttempts = retryableRequest ? 3 : 1;

    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      try {
        response = await fetch(API + url, {
          ...options,
          headers: {
            ...headers,
            ...options.headers
          }
        });
        break;
      } catch {
        if (attempt < maxAttempts - 1) {
          await new Promise(resolve => setTimeout(resolve, 2500 * (attempt + 1)));
        }
      }
    }

    if (!response) {
      throw new Error("The PropertySetu backend is waking up or temporarily unreachable. We retried automatically; please wait a few seconds and try again.");
    }

    if (response.status === 204) {
      return null;
    }

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      if (url === "/api/auth/login" && response.status === 401) {
        throw new Error("Invalid username or password.");
      }

      if ([502, 503, 504].includes(response.status)) {
        throw new Error("The PropertySetu backend is temporarily unavailable or waking up. Please wait a few seconds and try again.");
      }

      if (response.status === 401 || response.status === 403) {
        sessionStorage.removeItem("property_registration_token");
        throw new Error("Your session expired or you are not allowed to do that. Please log in again.");
      }

      throw new Error(data.message || data.error || "Request could not be completed. Please try again.");
    }

    return data;
  }

  async function openProtectedDocument(applicationId, documentId) {
    try {
      const token = user?.token || sessionStorage.getItem("property_registration_token");
      const response = await fetch(`${API}/api/applications/${applicationId}/documents/${documentId}/download`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      if (!response.ok) {
        throw new Error("Unable to open the protected document");
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank", "noopener,noreferrer");
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (err) {
      setError(err.message);
    }
  }

  function clearMessages() {
    setMessage("");
    setError("");
    setValidationErrors([]);
  }

  function showValidation(errors) {
    setMessage("");
    setValidationErrors(errors);
    setError("");
  }

  function logout() {
    setBusy(false);
    setUser(null);
    setOfficerMode(false);
    setLoginForm({ username: "", password: "" });
    setOwner(null);
    setProperty(null);
    setApplication(null);
    setPayment(null);
    setProperties([]);
    setApplications([]);
    setApplicantApplications([]);
    setSelectedApplication(null);
    setSelectedDocuments([]);
    setAuditEvents([]);
    setUploadedDocuments([]);
    setSubmissionAcknowledged(false);
    setFile(null);
    setRegisterPasswordError("");
    setRegisterConfirmPassword("");
    setRegisterPasswordVisible(false);
    setOtpCooldowns({ EMAIL: 0, PHONE: 0 });
    setRegisterConfirmPasswordVisible(false);
    setStep("home");
    clearMessages();
    sessionStorage.removeItem("property_registration_token");
  }

  async function enterApplicantWorkspace(data) {
    // Account creation and sign-in share the same applicant workspace hydration path.
    // All existing records are loaded from the backend/TiDB after authentication.
    setUser(data);
    sessionStorage.setItem("property_registration_token", data.token);
    setWorkspaceLoading(true);
    setStep("owner");
    setMessage(`Welcome, ${data.username}. Loading your saved PropertySetu records…`);

    void (async () => {
      try {
        const [savedApplications, savedProperties, existingOwner] = await Promise.all([
          request("/api/applications"),
          request("/api/properties/me").catch(() => []),
          request("/api/owners/me").catch(() => null)
        ]);

        setApplicantApplications(savedApplications || []);
        setProperties(savedProperties || []);
        void loadPaymentHistory(savedApplications || []);

        if (existingOwner) {
          setOwner(existingOwner);
          setOwnerForm({
            name: existingOwner.name || "",
            address: existingOwner.address || "",
            phone: existingOwner.phone || data.phone || "",
            identityNumber: existingOwner.identityNumber || ""
          });
        } else {
          setOwnerForm(previous => ({
            ...previous,
            phone: previous.phone || data.phone || ""
          }));
        }

        const current = [...(savedApplications || [])]
          .filter(item => item.status !== "REJECTED")
          .sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))[0];
        const currentProperty = current
          ? (savedProperties || []).find(item => item.id === current.propertyId)
          : null;

        if (current && currentProperty) {
          setApplication(current);
          setProperty(currentProperty);
          setPurpose(current.purpose || "");

          if (current.status === "DRAFT" || current.status === "NEEDS_CORRECTION") {
            const documents = await request(`/api/applications/${current.id}/documents`).catch(() => []);
            setUploadedDocuments(documents || []);
            if (current.status === "NEEDS_CORRECTION") {
              const savedPayment = await request(`/api/payments/application/${current.id}`).catch(() => null);
              setPayment(savedPayment);
            }
            void loadAuditHistory(current.id);
            setStep("documents");
            setMessage(current.status === "NEEDS_CORRECTION"
              ? "An officer requested a document correction. Replace the rejected document version, then resubmit your application. Your confirmed payment remains valid."
              : `Welcome back, ${data.username}. Your application is ready to continue.`);
          } else if (["SUBMITTED", "PAYMENT_PENDING"].includes(current.status)) {
            const savedPayment = await request(`/api/payments/application/${current.id}`).catch(() => null);
            setPayment(savedPayment);
            void loadAuditHistory(current.id);
            setStep("payment");
            setMessage(savedPayment
              ? `Welcome back, ${data.username}. Your payment is ready to continue.`
              : `Welcome back, ${data.username}. Your application is ready for payment.`);
          } else {
            const savedPayment = await request(`/api/payments/application/${current.id}`).catch(() => null);
            setPayment(savedPayment);
            void loadAuditHistory(current.id);
            setStep("paymentComplete");
            setMessage(`Welcome back, ${data.username}. Your application status is ${current.status}.`);
          }
        } else if (existingOwner) {
          setStep("property");
          setMessage(`Welcome back, ${data.username}. Your saved owner profile is ready.`);
        } else {
          setStep("owner");
          setMessage(`Welcome, ${data.username}. Let’s create your owner profile.`);
        }
      } catch {
        setError("Your account is signed in, but saved application records could not be loaded yet. Use Refresh status to try again.");
      } finally {
        setWorkspaceLoading(false);
      }
    })();
  }

  async function login(event) {
    event.preventDefault();
    if (busy) return;    clearMessages();
    const errors = [];
    if (!loginForm.username.trim()) errors.push("Enter your username.");
    if (!loginForm.password) errors.push("Enter your password.");
    if (errors.length) { showValidation(errors); return; }

    setBusy(true);

    try {
      const data = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(loginForm)
      });

      setUser(data);
      sessionStorage.setItem("property_registration_token", data.token);

      if (data.role === "OFFICER" || data.role === "ADMIN") {
        const applicationsData = await request("/api/applications");
        setApplications(applicationsData);
        if (data.role === "ADMIN") {
          await loadAdminUsers();
        }
        setOfficerMode(true);
        setMessage(`Welcome, ${data.username}. Officer workspace is ready.`);
        return;
      }

      await enterApplicantWorkspace(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function register(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const errors = [];
    if (!registerForm.username.trim()) errors.push("Enter a username.");
    if (!registerForm.email.trim()) errors.push("Enter your email address.");
    else if (!/^\S+@\S+\.\S+$/.test(registerForm.email.trim())) errors.push("Enter a valid email address.");
    if (!/^\d{10}$/.test(registerForm.phone.trim())) errors.push("Enter a 10-digit mobile number.");
    if (registerForm.password.length < 6) errors.push("Password must be at least 6 characters.");
    if (registerForm.password.length > 100) errors.push("Password cannot exceed 100 characters.");
    if (registerForm.password !== registerConfirmPassword) errors.push("Passwords do not match.");

    if (errors.length) {
      showValidation(errors);
      return;
    }

    setBusy(true);

    try {
      const data = await request("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(registerForm)
      });

      setRegisterForm({ username: "", password: "", email: "", phone: "" });
      setRegisterConfirmPassword("");
      setRegisterPasswordVisible(false);
      setRegisterConfirmPasswordVisible(false);
      setRegisterPasswordError("");
      setMessage(`Account created successfully. Welcome to PropertySetu, ${data.username}.`);
      await enterApplicantWorkspace(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function createOwner(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const errors = [];
    if (!ownerForm.name.trim()) errors.push("Enter the owner's full name.");
    if (!ownerForm.address.trim()) errors.push("Enter the owner's address.");
    if (!/^[0-9]{10}$/.test(ownerForm.phone.trim())) errors.push("Enter a 10-digit mobile number.");
    if (!ownerForm.identityNumber.trim()) errors.push("Enter an identity/reference number.");
    if (errors.length) { showValidation(errors); return; }

    setBusy(true);

    try {
      const data = await request("/api/owners", {
        method: "POST",
        body: JSON.stringify({
          userId: user.id,
          ...ownerForm
        })
      });

      setOwner(data);
      setMessage("Owner profile created successfully.");
      setStep("property");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function createProperty(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const errors = [];
    if (!propertyForm.propertyNumber.trim()) errors.push("Enter a property reference number.");
    if (!propertyForm.propertyType) errors.push("Select a property type.");
    if (!propertyForm.area || Number(propertyForm.area) <= 0) errors.push("Enter an area greater than 0.");
    if (!propertyForm.description.trim()) errors.push("Add a short property description.");
    if (errors.length) { showValidation(errors); return; }

    const savedMatch = findSavedProperty(propertyForm.propertyNumber);
    if (savedMatch) {
      setProperty(savedMatch);
      setMessage("This property reference is already saved in your PropertySetu account. Use the saved record below instead of creating a duplicate.");
      setStep("property");
      return;
    }

    setBusy(true);

    try {
      const payload = {
        ownerId: owner.id,
        propertyNumber: propertyForm.propertyNumber,
        propertyType: propertyForm.propertyType,
        area: Number(propertyForm.area),
        description: propertyForm.description
      };

      const data = editingPropertyId
        ? await request(`/api/properties/${editingPropertyId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
          })
        : await request("/api/properties", {
            method: "POST",
            body: JSON.stringify(payload)
          });

      setProperty(data);
      setProperties(previous => editingPropertyId
        ? previous.map(item => item.id === data.id ? data : item)
        : [...previous, data]);
      setEditingPropertyId(null);
      setMessage(editingPropertyId ? "Property details updated successfully." : "Property created successfully.");
      setStep("location");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function createLocation(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const errors = [];
    if (!locationForm.address.trim()) errors.push("Enter the property address.");
    if (!locationForm.city.trim()) errors.push("Enter the city.");
    if (!locationForm.district.trim()) errors.push("Enter the district.");
    if (!locationForm.state.trim()) errors.push("Enter the state.");
    if (!/^[0-9]{6}$/.test(locationForm.pincode.trim())) errors.push("Enter a 6-digit PIN code.");
    if (errors.length) { showValidation(errors); return; }

    setBusy(true);

    try {
      const existingLocation = await request(`/api/locations/property/${property.id}`).catch(() => null);
      const locationPayload = {
        propertyId: property.id,
        ...locationForm
      };
      if (!existingLocation) {
        await request("/api/locations", {
          method: "POST",
          body: JSON.stringify(locationPayload)
        });
      } else {
        await request(`/api/locations/${existingLocation.id}`, {
          method: "PUT",
          body: JSON.stringify(locationPayload)
        });
      }

      setMessage(existingLocation ? "Property location updated successfully." : "Property location saved successfully.");
      setStep("application");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function createApplication(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const finalPurpose = purpose.trim() || purposeType.trim();
    if (!finalPurpose) {
      showValidation(["Select or enter the purpose of this application."]);
      return;
    }

    setBusy(true);

    try {
      const data = application?.id
        ? await request(`/api/applications/${application.id}`, {
            method: "PUT",
            body: JSON.stringify({
              userId: user.id,
              propertyId: property.id,
              purpose: finalPurpose
            })
          })
        : await request("/api/applications", {
            method: "POST",
            body: JSON.stringify({
              userId: user.id,
              propertyId: property.id,
              purpose: finalPurpose
            })
          });

      setApplication(data);
      setApplicantApplications(previous => {
        const withoutCurrent = previous.filter(item => item.id !== data.id);
        return [data, ...withoutCurrent];
      });
      const documents = await request(`/api/applications/${data.id}/documents`).catch(() => []);
      setUploadedDocuments(documents || []);
      setMessage("Registration application ready.");
      setStep("documents");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function uploadDocument(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();
    setBusy(true);

    if (!file) {
      setError("Please choose a document first.");
      setBusy(false);
      return;
    }

    const formData = new FormData();
    formData.append("documentType", documentType);
    formData.append("file", file);

    try {
      const uploaded = await request(`/api/applications/${application.id}/documents`, {
        method: "POST",
        body: formData
      });

      setUploadedDocuments(previous => [uploaded, ...previous]);
      setFile(null);
      setMessage(`${documentType.replaceAll("_", " ")} uploaded successfully.`);
    } catch (err) {
      setError(err.message);
    } finally {      setBusy(false);
    }
  }

  async function deleteDocument(documentId) {
    if (busy) return;
    clearMessages();

    const confirmed = window.confirm("Remove this draft document from the application?");
    if (!confirmed) return;

    setBusy(true);
    try {
      await request(`/api/applications/${application.id}/documents/${documentId}`, {
        method: "DELETE"
      });
      setUploadedDocuments(previous => previous.filter(document => document.id !== documentId));
      setMessage("Draft document removed.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function deleteDraftApplication() {
    if (busy || !application?.id || application.status !== "DRAFT") return;
    clearMessages();

    const confirmed = window.confirm("Delete this draft application and its uploaded demo documents?");
    if (!confirmed) return;

    setBusy(true);
    try {
      await request(`/api/applications/${application.id}`, { method: "DELETE" });
      setApplicantApplications(previous => previous.filter(item => item.id !== application.id));
      setUploadedDocuments([]);
      setPayment(null);
      setPaymentDemoAcknowledged(false);
      setApplication(null);
      setPurpose("");
      setPurposeType("");
      setMessage("Draft application deleted. Your property record remains saved.");
      setStep("application");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function submitApplication() {
    if (busy) return;
    clearMessages();
    setBusy(true);

    try {
      const data = await request(
        `/api/applications/${application.id}/submit`,
        { method: "POST" }
      );

      setApplication(data);
      setPaymentDemoAcknowledged(false);
      if (data.status === "RESUBMITTED") {
        setMessage("Corrected documents resubmitted successfully. Your assigned officer can continue the review; no second application fee is due.");
        setStep("paymentComplete");
      } else {
        setMessage("Application submitted successfully. Continue to the Razorpay Test Mode payment step.");
        setStep("payment");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function reconcilePaymentStatus(paymentRecord = payment, moveToComplete = true) {
    if (!paymentRecord?.id) return null;

    try {
      const reconciled = await request("/api/payments/reconcile", {
        method: "POST",
        body: JSON.stringify({ paymentId: paymentRecord.id })
      });

      setPayment(reconciled);
      setApplication(reconciled.application);

      if (reconciled.paymentStatus === "SUCCESS") {
        setPaymentDemoAcknowledged(false);
        setMessage("Razorpay Test Mode payment confirmed successfully.");
        if (moveToComplete) setStep("paymentComplete");
      }

      return reconciled;
    } catch (err) {
      if (moveToComplete) setError(err.message);
      return null;
    }
  }

  async function createPayment() {
    if (busy) return;
    clearMessages();

    if (!paymentDemoAcknowledged) {
      showValidation(["Confirm that you will use Razorpay Test Mode only before opening checkout. Never enter a real card number, CVV, UPI PIN, bank credential or real payment OTP."]);
      return;
    }
    setBusy(true);

    try {
      // Reuse an existing pending order so retries do not create multiple
      // pending Razorpay orders for the same application.
      const data = payment && payment.paymentStatus !== "SUCCESS" && payment.gatewayOrderId
        ? payment
        : await request("/api/payments/order", {            method: "POST",
            body: JSON.stringify({              applicationId: application.id,
              amount: 500
            })
          });

      setPayment(data);

      if (!window.Razorpay) {
        throw new Error("Razorpay Checkout could not be loaded. Please refresh the page and try again.");
      }

      if (!data.gatewayKeyId) {
        throw new Error("Razorpay test checkout is not configured on the server yet.");
      }

      const checkout = new window.Razorpay({
        key: data.gatewayKeyId,
        amount: Math.round(Number(data.amount) * 100),
        currency: data.currency || "INR",
        name: "PropertySetu",
        description: "PropertySetu academic demonstration — Razorpay Test Mode",
        order_id: data.gatewayOrderId,
        prefill: {
          name: owner?.name || user?.username || "",
          email: user?.email || ""
        },
        notes: {
          application: application.applicationNumber
        },
        // Keep Razorpay's standard Test Mode method selection. Forcing a
        // custom UPI-only block can return "No appropriate payment method
        // found" when that method is unavailable for the Test account/session.
        // The UI below directs the evaluator to Razorpay's UPI simulator.
        theme: {
          color: "#172033"
        },
        handler: async response => {
          setBusy(true);
          clearMessages();

          try {
            const verified = await request("/api/payments/verify", {
              method: "POST",
              body: JSON.stringify({
                paymentId: data.id,
                razorpayOrderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature
              })
            });

            setPayment(verified);
            setApplication(verified.application);
            setPaymentDemoAcknowledged(false);
            setMessage("Razorpay Test Mode payment verified successfully.");
            setStep("paymentComplete");

            void request("/api/applications")
              .then(refreshedApplications => {
                const records = refreshedApplications || [];
                setApplicantApplications(records);
                void loadPaymentHistory(records);
              })
              .catch(() => {});
          } catch (err) {
            const reconciled = await reconcilePaymentStatus(data, true);
            if (!reconciled || reconciled.paymentStatus !== "SUCCESS") {
              setError(err.message);
            }
          } finally {
            setBusy(false);
          }
        },
        modal: {
          ondismiss: async () => {
            setBusy(true);
            const reconciled = await reconcilePaymentStatus(data, true);
            if (!reconciled || reconciled.paymentStatus !== "SUCCESS") {
              setMessage("Payment window closed. If you completed the test payment, use “Refresh payment status” below.");
            }
            setBusy(false);
          }
        }
      });

      checkout.open();
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  function extractMsg91Value(value, keys) {
    if (!value) return "";
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = extractMsg91Value(item, keys);
        if (found) return found;
      }
      return "";
    }
    if (typeof value !== "object") return "";

    for (const key of keys) {
      if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
    }

    for (const child of Object.values(value)) {
      const found = extractMsg91Value(child, keys);
      if (found) return found;
    }
    return "";
  }

  function msg91Identifier(channel) {
    if (channel === "EMAIL") return verificationEmail.trim().toLowerCase();
    const digits = verificationPhone.replace(/\D/g, "");
    return digits.length === 10 ? `91${digits}` : digits;
  }

  function initMsg91Widget(identifier) {
    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN || typeof window.initSendOTP !== "function") {
      throw new Error("MSG91 OTP is not ready. Please refresh the page and try again.");
    }

    window.initSendOTP({
      widgetId: MSG91_WIDGET_ID,
      tokenAuth: MSG91_WIDGET_TOKEN,
      identifier,
      exposeMethods: true,
      captchaRenderId: "",
      success: () => {},
      failure: () => {}
    });
  }

  function sendMsg91Otp(channel, explicitIdentifier = "") {
    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
      return request("/api/auth/demo-otp/send", {
        method: "POST",
        body: JSON.stringify({ username: verificationUsername || explicitIdentifier, channel })
      }).then(data => {
        setDemoOtpCodes(previous => ({ ...previous, [channel]: data.code || "" }));
        return data;
      });
    }

    return new Promise((resolve, reject) => {
      try {
        const identifier = explicitIdentifier
          ? (channel === "EMAIL"
              ? explicitIdentifier.trim().toLowerCase()
              : (() => {
                  const digits = explicitIdentifier.replace(/\D/g, "");
                  return digits.length === 10 ? `91${digits}` : digits;
                })())
          : msg91Identifier(channel);

        initMsg91Widget(identifier);

        window.sendOtp(
          identifier,
          data => {
            const reqId = extractMsg91Value(data, ["reqId", "reqID", "requestId", "requestID"]);
            setMsg91ReqIds(previous => ({ ...previous, [channel]: reqId }));
            resolve(data);
          },
          error => reject(new Error(error?.message || "MSG91 could not send the OTP. Please try again."))
        );
      } catch (err) {
        reject(err);
      }
    });
  }

  function verifyMsg91Otp(channel) {
    if (busy) return;
    clearMessages();

    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
      const code = verificationCodes[channel].trim();
      if (!/^\d{6}$/.test(code)) {
        showValidation(["Enter the 6-digit demo OTP for your " + (channel === "EMAIL" ? "email" : "mobile number") + "."]);
        return;
      }
      setBusy(true);
      request("/api/auth/demo-otp/verify", {
        method: "POST",
        body: JSON.stringify({
          username: verificationUsername,
          channel,
          code
        })
      })
        .then(verified => {
          const nextState = {
            EMAIL: Boolean(verified.emailVerified),
            PHONE: Boolean(verified.phoneVerified)
          };
          setVerificationState(nextState);
          setVerificationCodes(previous => ({ ...previous, [channel]: "" }));
          setDemoOtpCodes(previous => ({ ...previous, [channel]: "" }));
          if (nextState.EMAIL && nextState.PHONE) {
            setOtpCooldowns({ EMAIL: 0, PHONE: 0 });
            setMessage("Both contacts are verified. You can now sign in.");
            setStep("login");
          } else {
            setMessage((channel === "EMAIL" ? "Email" : "Mobile number") + " verified. Verify the remaining contact method.");
          }
        })
        .catch(err => setError(err.message))
        .finally(() => setBusy(false));
      return;
    }

    const code = verificationCodes[channel].trim();
    const reqId = msg91ReqIds[channel];
    if (!/^\d{6}$/.test(code)) {
      showValidation([`Enter the 6-digit OTP sent to your ${channel === "EMAIL" ? "email" : "mobile number"}.`]);
      return;
    }
    if (!reqId) {
      showValidation(["This OTP session is no longer active. Request a new code first."]);
      return;
    }

    setBusy(true);

    try {
      initMsg91Widget(msg91Identifier(channel));

      window.verifyOtp(
        code,
        async data => {
          try {
            const accessToken = extractMsg91Value(data, [
              "access-token",
              "accessToken",
              "access_token",
              "token",
              "jwt"
            ]);

            if (!accessToken) {
              throw new Error("MSG91 verified the OTP but did not return a verification token.");
            }

            const verified = await request("/api/auth/verify-msg91-token", {
              method: "POST",
              body: JSON.stringify({
                username: verificationUsername,
                channel,
                accessToken
              })
            });

            const nextState = {
              EMAIL: Boolean(verified.emailVerified),
              PHONE: Boolean(verified.phoneVerified)
            };

            setVerificationState(nextState);
            setVerificationCodes(previous => ({ ...previous, [channel]: "" }));

            if (nextState.EMAIL && nextState.PHONE) {
              setOtpCooldowns({ EMAIL: 0, PHONE: 0 });
              setMessage("Both contact methods are verified. You can now sign in.");
              setStep("login");
            } else {
              setMessage(`${channel === "EMAIL" ? "Email" : "Mobile number"} verified. Verify the remaining contact method.`);
            }
          } catch (err) {
            setError(err.message);
          } finally {
            setBusy(false);
          }
        },
        error => {
          setError(error?.message || "Incorrect or expired OTP. Please try again.");
          setBusy(false);
        },
        reqId
      );
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  function resendMsg91Otp(channel) {
    if (busy || otpCooldowns[channel] > 0) return;
    clearMessages();

    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
      setBusy(true);
      sendMsg91Otp(channel)
        .then(() => {
          setOtpCooldowns(previous => ({ ...previous, [channel]: 30 }));
          setMessage("A new demo " + (channel === "EMAIL" ? "email" : "mobile") + " OTP has been generated.");
        })
        .catch(err => setError(err.message))
        .finally(() => setBusy(false));
      return;
    }

    const reqId = msg91ReqIds[channel];
    if (!reqId) {
      setBusy(true);
      sendMsg91Otp(channel)
        .then(() => {
          setOtpCooldowns(previous => ({ ...previous, [channel]: 30 }));
          setMessage(`A new ${channel === "EMAIL" ? "email" : "mobile"} OTP has been sent.`);
        })
        .catch(err => setError(err.message))
        .finally(() => setBusy(false));
      return;
    }

    setBusy(true);
    try {
      initMsg91Widget(msg91Identifier(channel));
      window.retryOtp(
        channel === "EMAIL" ? "3" : "11",
        data => {
          const nextReqId = extractMsg91Value(data, ["reqId", "reqID", "requestId", "requestID"]) || reqId;
          setMsg91ReqIds(previous => ({ ...previous, [channel]: nextReqId }));
          setVerificationCodes(previous => ({ ...previous, [channel]: "" }));
          setOtpCooldowns(previous => ({ ...previous, [channel]: 30 }));
          setMessage(`A new ${channel === "EMAIL" ? "email" : "mobile"} OTP has been sent.`);
          setBusy(false);
        },
        error => {
          setError(error?.message || "Unable to resend the OTP. Please try again.");
          setBusy(false);
        },
        reqId
      );
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  async function requestPasswordReset(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const email = forgotEmail.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      showValidation(["Enter the email address associated with your account."]);
      return;
    }
    setBusy(true);
    try {
      await request("/api/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify({ email })
      });

      setResetReqId("");
      setResetAccessToken("");
      setResetCode("");
      setNewPassword("");

      let reqId = "";
      if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
        const data = await request("/api/auth/demo-otp/send", {
          method: "POST",
          body: JSON.stringify({ username: email, channel: "RESET" })
        });
        setDemoOtpCodes(previous => ({ ...previous, RESET: data.code || "" }));
        reqId = "DEMO";
      } else {
        const data = await sendMsg91Otp("EMAIL", email);
        reqId = extractMsg91Value(data, ["reqId", "reqID", "requestId", "requestID"]);
      }
      setResetReqId(reqId);
      setMessage(MSG91_WIDGET_ID && MSG91_WIDGET_TOKEN
        ? "If an account matches that email, a password-reset OTP has been sent."
        : "Academic fallback mode: a demo reset OTP has been generated and is shown below.");
      setStep("resetPassword");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function verifyPasswordResetOtp() {
    if (busy) return;
    clearMessages();

    if (!/^\d{6}$/.test(resetCode.trim())) {
      showValidation(["Enter the 6-digit password-reset OTP."]);
      return;
    }
    if (!resetReqId) {      showValidation(["This password-reset OTP session is no longer active. Request a new code."]);
      return;
    }
    setBusy(true);

    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
      request("/api/auth/demo-otp/verify", {
        method: "POST",
        body: JSON.stringify({
          username: forgotEmail.trim().toLowerCase(),
          channel: "RESET",
          code: resetCode.trim()
        })
      })
        .then(() => {
          setResetAccessToken("DEMO");
          setMessage("Demo reset OTP verified. Choose your new password.");
        })
        .catch(err => setError(err.message))
        .finally(() => setBusy(false));
      return;
    }

    try {
      initMsg91Widget(forgotEmail.trim().toLowerCase());
      window.verifyOtp(
        resetCode.trim(),
        data => {
          const accessToken = extractMsg91Value(data, [
            "access-token",
            "accessToken",
            "access_token",
            "token",
            "jwt"
          ]);
          if (!accessToken) {
            setError("MSG91 verified the OTP but did not return a reset verification token.");
            setBusy(false);
            return;
          }
          setResetAccessToken(accessToken);
          setResetCode("");
          setMessage("Email verified. Choose your new password.");
          setBusy(false);
        },
        error => {
          setError(error?.message || "Incorrect or expired password-reset OTP. Please try again.");
          setBusy(false);
        },
        resetReqId
      );
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  function resendPasswordResetOtp() {
    if (busy) return;
    clearMessages();
    setBusy(true);

    if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
      request("/api/auth/demo-otp/send", {
        method: "POST",
        body: JSON.stringify({ username: forgotEmail.trim().toLowerCase(), channel: "RESET" })
      })
        .then(data => {
          setDemoOtpCodes(previous => ({ ...previous, RESET: data.code || "" }));
          setResetReqId("DEMO");
          setResetAccessToken("");
          setResetCode("");
          setMessage("A new demo password-reset OTP has been generated.");
        })
        .catch(err => setError(err.message))
        .finally(() => setBusy(false));
      return;
    }

    sendMsg91Otp("EMAIL", forgotEmail.trim().toLowerCase())
      .then(data => {
        const nextReqId = extractMsg91Value(data, ["reqId", "reqID", "requestId", "requestID"]);
        setResetReqId(nextReqId);
        setResetAccessToken("");
        setResetCode("");
        setMessage("A new password-reset OTP has been sent.");
      })
      .catch(err => setError(err.message))
      .finally(() => setBusy(false));
  }

  async function submitPasswordReset(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const errors = [];
    if (!resetAccessToken) errors.push("Verify the email OTP before choosing a new password.");
    if (newPassword.length < 6) errors.push("New password must be at least 6 characters.");
    if (newPassword.length > 100) errors.push("New password cannot exceed 100 characters.");
    if (errors.length) {
      showValidation(errors);
      return;
    }

    setBusy(true);
    try {
      if (!MSG91_WIDGET_ID || !MSG91_WIDGET_TOKEN) {
        await request("/api/auth/demo-otp/reset-password", {
          method: "POST",
          body: JSON.stringify({
            username: forgotEmail.trim().toLowerCase(),
            channel: "RESET",
            code: resetCode.trim(),
            newPassword
          })
        });
      } else {
        await request("/api/auth/reset-password", {
          method: "POST",
          body: JSON.stringify({
            email: forgotEmail.trim().toLowerCase(),
            accessToken: resetAccessToken,
            newPassword
          })
        });
      }
      setLoginForm({ username: "", password: "" });
      setForgotEmail("");
      setResetCode("");
      setResetReqId("");
      setResetAccessToken("");
      setNewPassword("");
      setMessage("Password reset successfully. You can now sign in.");
      setStep("login");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function update(setter, field, value) {
    setter(previous => ({ ...previous, [field]: value }));
  }

  function normalizePropertyReference(value) {
    return String(value || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, " ");
  }

  function findSavedProperty(reference) {
    const normalized = normalizePropertyReference(reference);
    if (!normalized) return null;
    return properties.find(item => normalizePropertyReference(item.propertyNumber) === normalized) || null;
  }

  function maskValue(value, visible = 4) {
    const text = String(value || "");
    if (!text) return "Protected";
    if (text.length <= visible) return "••••";
    return `${"•".repeat(Math.max(4, text.length - visible))}${text.slice(-visible)}`;
  }

  function maskEmail(value) {
    const text = String(value || "").trim();
    const at = text.indexOf("@");
    if (at <= 1) return "protected email";
    return text.slice(0, 2) + "•••" + text.slice(at);
  }

  function maskPhone(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (digits.length < 4) return "protected mobile number";
    return "••••••" + digits.slice(-4);
  }

  function goToPreviousStep() {
    const previousSteps = {
      property: "owner",
      location: "property",
      application: "location",
      documents: "application",
      submit: "documents",
      payment: "submit"
    };

    const previousStep = previousSteps[step];
    if (previousStep) {
      clearMessages();
      setStep(previousStep);
    }
  }

  async function loadAdminUsers() {
    setAdminUsersLoading(true);
    try {
      const data = await request("/api/admin/users");
      setAdminUsers(Array.isArray(data) ? data : []);
    } catch (err) {
      setAdminUsers([]);
      setError(err.message);
    } finally {
      setAdminUsersLoading(false);
    }
  }

  async function createAdminManagedUser(event) {
    event.preventDefault();
    if (busy) return;
    clearMessages();

    const username = adminUserForm.username.trim();
    const email = adminUserForm.email.trim().toLowerCase();
    const phone = adminUserForm.phone.trim();
    const password = adminUserForm.password;

    const errors = [];
    if (!username) errors.push("Enter a username.");
    if (!/^\S+@\S+\.\S+$/.test(email)) errors.push("Enter a valid email address.");
    if (phone && !/^\d{10}$/.test(phone)) errors.push("Mobile number must be 10 digits.");
    if (password.length < 6 || password.length > 100) errors.push("Temporary password must be 6-100 characters.");
    if (!["APPLICANT", "OFFICER", "ADMIN"].includes(adminUserForm.role)) errors.push("Select a valid role.");

    if (errors.length) {
      showValidation(errors);
      return;
    }

    setBusy(true);
    try {
      await request("/api/admin/users", {
        method: "POST",
        body: JSON.stringify({ username, email, phone, password, role: adminUserForm.role })
      });
      setAdminUserForm({ username: "", email: "", phone: "", password: "", role: "OFFICER" });
      await loadAdminUsers();
      setMessage("User account created successfully.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function updateAdminManagedUser(id, changes) {
    if (busy) return;
    clearMessages();
    setBusy(true);
    try {
      const updated = await request("/api/admin/users/" + id, {
        method: "PUT",
        body: JSON.stringify(changes)
      });
      setAdminUsers(previous => previous.map(account => account.id === updated.id ? updated : account));
      setMessage("User access settings updated successfully.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function assignOfficerToApplication(event) {
    event.preventDefault();
    if (!selectedApplication?.id || user?.role !== "ADMIN") return;
    if (!assignmentForm.officerId || !assignmentForm.reason.trim()) {
      showValidation(["Choose an active officer and provide the assignment reason."]);
      return;
    }
    setBusy(true);
    clearMessages();
    try {
      const updated = await request(
        `/api/admin/applications/${selectedApplication.id}/assignment`,
        {
          method: "POST",
          body: JSON.stringify({
            officerId: Number(assignmentForm.officerId),
            reason: assignmentForm.reason.trim()
          })
        }
      );
      setSelectedApplication(updated);
      setApplications(previous => previous.map(item => item.id === updated.id ? updated : item));
      setAssignmentForm(previous => ({ ...previous, officerId: String(updated.assignedOfficerId || "") }));
      setMessage(`Application assigned to ${updated.assignedOfficerUsername || "the selected officer"}.`);
      await loadAuditHistory(updated.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function openOfficerDashboard() {
    clearMessages();
    try {
      const data = await request("/api/applications");
      setApplications(data);
      setSelectedApplication(null);
      setSelectedDocuments([]);
      setOfficerMode(true);
      if (user?.role === "ADMIN") await loadAdminUsers();
    } catch (err) {
      setError(err.message);
    }
  }

  const visibleApplications = applications
    .filter(item => {
      const matchesStatus = statusFilter === "ALL" || item.status === statusFilter;
      const query = applicationSearch.trim().toLowerCase();
      const matchesSearch = !query
        || item.applicationNumber?.toLowerCase().includes(query)
        || item.applicantUsername?.toLowerCase().includes(query)
        || item.propertyNumber?.toLowerCase().includes(query);
      return matchesStatus && matchesSearch;
    })
    .sort((left, right) => {
      if (applicationSort === "OLDEST") {
        return new Date(left.createdAt || 0) - new Date(right.createdAt || 0);
      }
      if (applicationSort === "STATUS") {
        return String(left.status || "").localeCompare(String(right.status || ""));
      }
      return new Date(right.createdAt || 0) - new Date(left.createdAt || 0);
    });

  const propertyReferenceMatch = findSavedProperty(propertyForm.propertyNumber);

  async function loadAuditHistory(applicationId) {
    try {
      setAuditEvents(await request(`/api/audit/applications/${applicationId}`));
    } catch (err) {
      setAuditEvents([]);
      setError(err.message);
    }
  }

  async function selectApplicantApplication(selected) {
    if (!selected) return;
    setApplication(selected);
    const savedProperty = properties.find(item => item.id === selected.propertyId);
    if (savedProperty) {
      setProperty(savedProperty);
    }
    setPurpose(selected.purpose || "");

    try {
      const [documents, savedPayment] = await Promise.all([
        request(`/api/applications/${selected.id}/documents`).catch(() => []),
        request(`/api/payments/application/${selected.id}`).catch(() => null)
      ]);
      setUploadedDocuments(documents || []);
      setPayment(savedPayment);
      setPaymentDemoAcknowledged(false);
      await loadAuditHistory(selected.id);

      if (selected.status === "DRAFT" || selected.status === "NEEDS_CORRECTION") {
        setStep("documents");
      } else if (["SUBMITTED", "PAYMENT_PENDING"].includes(selected.status)) {
        setStep("payment");
      } else if (["PAID", "UNDER_VERIFICATION", "RESUBMITTED", "VERIFIED", "COMPLETED", "REJECTED"].includes(selected.status)) {
        setStep("paymentComplete");
      } else {
        setStep("payment");
      }
    } catch (err) {
      setError(err.message);
    }
  }

  async function refreshApplicantApplications() {
    clearMessages();
    try {
      const data = await request("/api/applications");
      setApplicantApplications(data || []);
      await loadPaymentHistory(data || []);
      const current = application && data.find(item => item.id === application.id);
      const selected = current || (!application
        ? [...(data || [])].sort((left, right) => new Date(right.createdAt || 0) - new Date(left.createdAt || 0))[0]
        : null);
      if (selected) {
        await selectApplicantApplication(selected);
      }
      setMessage("Application status and saved records refreshed.");
    } catch (err) {
      setError(err.message);
    }
  }

  async function loadPaymentHistory(records = applicantApplications) {
    if (!records?.length) {
      setPaymentHistory([]);
      return;
    }

    setPaymentHistoryLoading(true);
    try {
      const results = await Promise.all(
        records.slice(0, 8).map(async record => {
          const paymentRecord = await request(`/api/payments/application/${record.id}`).catch(() => null);
          return paymentRecord ? { ...paymentRecord, application: record } : null;
        })
      );
      setPaymentHistory(results.filter(Boolean));
    } finally {
      setPaymentHistoryLoading(false);
    }
  }

  function applicationProgress() {
    if (step === "paymentComplete") return 7;
    const index = ["owner", "property", "location", "application", "documents", "submit", "payment"].indexOf(step);
    return index < 0 ? 0 : index + 1;
  }

  function companionGuidance() {
    const guidance = {
      owner: ["Applicant information", "Enter the applicant details used for this academic workflow."],
      property: ["Property details", "Add the property record you want to connect to this application."],
      location: ["Property location", "Complete the address so the property record has a clear location."],
      application: ["Application details", "Choose the purpose and add any useful application note."],
      documents: ["Supporting documents", "Upload the three required demo document categories before review."],
      submit: ["Final review", "Check the summary and acknowledgement before submission."],
      payment: ["Test-mode payment", "Create and complete the demonstration payment to finish the workflow."]
    };
    return guidance[step] || ["Application workspace", "Use the guided sections below to continue your academic demonstration."];
  }
  async function verifySelected(status) {
    if (!selectedApplication) {
      setError("Select an application first.");
      return;    }

    clearMessages();

    try {
      const data = await request("/api/verifications", {
        method: "POST",
        body: JSON.stringify({
          applicationId: selectedApplication.id,
          verifiedByUserId: user.id,
          status,
          remarks
        })
      });

      setMessage(`Application ${status.toLowerCase()} successfully.`);
      setSelectedApplication(data.application);
      await loadAuditHistory(data.application.id);
      const refreshed = await request("/api/applications");
      setApplications(refreshed);
    } catch (err) {
      setError(err.message);
    }
  }

  if (step === "home" && !officerMode) {
    return (
      <main className="app public-home">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span>
            <span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
          <div className="nav-actions">
            <button className="nav-link" type="button" onClick={() => setShowAbout(previous => !previous)}>{showAbout ? "Hide overview" : "How it works"}</button>
            <button className="nav-ghost" type="button" onClick={() => { clearMessages(); setStep("login"); }}>Applicant sign in</button>
          </div>
        </header>

        <section className="hero-home">
          <div className="hero-home-copy">
            <div className="academic-badge">STUDENT-DEVELOPED · ACADEMIC DEMONSTRATION</div>
            <p className="eyebrow">PROPERTYSETU</p>
            <h1>Property application, guided from start to review.</h1>
            <p className="hero-lead">A property is more than a record. PropertySetu connects applicant information, property details, supporting documents, review and test-mode payment into one clear, traceable journey.</p>
            <div className="hero-actions">
              <button type="button" onClick={() => { clearMessages(); setStep("login"); }}>Explore the workflow <span>→</span></button>
              <button type="button" className="secondary-button" onClick={() => setShowAbout(true)}>See how it works</button>
            </div>
            <div className="trust-strip"><span>✓ JWT authentication</span><span>✓ Contact details stored with account</span><span>✓ Role-based access</span><span>✓ Razorpay test gateway</span><span>✓ Audit history</span></div>
            <div className={`backend-status ${backendStatus}`} role="status" aria-live="polite">
              <span aria-hidden="true">●</span>
              {backendStatus === "online" && "Backend ready"}
              {backendStatus === "checking" && "Preparing backend…"}
              {backendStatus === "unavailable" && "Backend temporarily unavailable"}
            </div>
          </div>
          <div className="hero-home-visual">
            <img src="/propertysetu-hero.svg" alt="Illustration representing a guided property application workflow" />
          </div>
        </section>

        <section className="academic-notice" aria-label="Academic project notice">
          <div className="notice-icon">i</div>
          <div>
            <strong>Academic demonstration</strong>
            <p>PropertySetu is a student-developed academic project. It is <b>not an official Government of Maharashtra, IGR Maharashtra, or government registration portal.</b> No official government registration is performed through this application.</p>
          </div>
        </section>

        <section className="workflow-showcase">
          <div className="section-heading"><p className="eyebrow">ONE CONNECTED WORKFLOW</p><h2>From account creation to application review</h2><p>Each stage builds on the information from the previous stage instead of making the user repeat the same details.</p></div>
          <div className="workflow-grid">
            {[
              ["01", "Applicant", "Create an account and manage your own application records."],
              ["02", "Property", "Capture owner, property and location information."],
              ["03", "Documents", "Organize supporting files by document category."],
              ["04", "Review", "Submit the application and follow its status."],
              ["05", "Payment", "Demonstrate an application-related fee in test mode."],
              ["06", "Officer", "Authorized users review documents and record a decision."]
            ].map(([number, title, description]) => (
              <article className="workflow-card" key={number}><span>{number}</span><h3>{title}</h3><p>{description}</p></article>
            ))}
          </div>
        </section>

        <section className="feature-row">
          <article><b>Authentication</b><span>JWT sessions with role-aware access.</span></article>
          <article><b>CRUD workflow</b><span>Applicant records, properties and application data.</span></article>
          <article><b>Search · Sort · Filter</b><span>Officer-side application discovery and review.</span></article>
          <article><b>Payment Gateway</b><span>Test-mode application payment flow.</span></article>
        </section>

        {showAbout && <section className="public-overview home-overview">
          <div><p className="eyebrow">WHAT THIS PROJECT DEMONSTRATES</p><h2>A realistic full-stack classroom workflow.</h2><p>PropertySetu follows the class-project scope: User → Owner → Property → Location → RegistrationApplication → Document → Verification → Payment. Optional email and forgot-password features are intentionally not presented as working features until corresponding backend endpoints exist.</p></div>
          <div className="overview-grid"><div><b>01</b><span>Prepare</span><small>Applicant and property information</small></div><div><b>02</b><span>Submit</span><small>Documents, acknowledgement and payment</small></div><div><b>03</b><span>Review</span><small>Officer verification and audit history</small></div></div>
        </section>}

        <footer className="public-footer"><span>PropertySetu · Student academic project</span><span>Test-mode payment · No official registration</span></footer>
      </main>
    );
  }

  if (workspaceLoading && user && !officerMode) {
    return (
      <main className="app auth-page">
        <section className="workspace-loading-card" aria-live="polite">
          <div className="workspace-loading-mark">PS</div>
          <p className="eyebrow">PROPERTYSETU · ACADEMIC WORKSPACE</p>
          <h1>Preparing your application workspace…</h1>
          <p>We’ve signed you in. Your saved application, property and applicant records are loading now.</p>
          <small>This can take a little longer when the academic backend is waking up. You can stay on this page safely.</small>
        </section>
      </main>
    );
  }

  if (step === "login" && !officerMode) {
    return (
      <main className="app auth-page">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span><span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
          <button className="nav-link" type="button" onClick={() => setStep("home")}>← Back to home</button>
        </header>

        <section className="login-intro">
          <div><p className="eyebrow">APPLICANT ACCESS</p><h1>Sign in to your application workspace.</h1><p>Continue your academic PropertySetu workflow or create a new applicant account.</p></div>
          <div className="mini-notice"><strong>Academic demonstration</strong><span>Not an official government registration portal.</span></div>
        </section>

        {message && <div className="message success" role="status">{message}</div>}
        {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
        {error && <div className="message error" role="alert">{error}</div>}

        <section className="card auth-card">
          <form onSubmit={login}>
            <div className="form-section-heading"><span className="step-icon">01</span><div><h2>Applicant sign in</h2><p className="muted">Use the credentials for your PropertySetu account.</p></div></div>
            <label htmlFor="login-username">Username <span>*</span></label>
            <input id="login-username" name="username" autoComplete="username" placeholder="" value={loginForm.username} onChange={e => update(setLoginForm, "username", e.target.value)} required />
            <small className="field-example">Example: rahul.sharma</small>
            <label htmlFor="login-password">Password <span>*</span></label>
            <div className="password-field"><input id="login-password" name="password" autoComplete="current-password" type={loginPasswordVisible ? "text" : "password"} placeholder="" value={loginForm.password} onChange={e => update(setLoginForm, "password", e.target.value)} required /><button type="button" className="password-toggle" onClick={() => setLoginPasswordVisible(previous => !previous)}>{loginPasswordVisible ? "Hide" : "Show"}</button></div>
            <small className="field-example">Enter the password you created for your account.</small>
            <button type="submit" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
            <button type="button" className="link-button auth-forgot" onClick={() => {
              clearMessages();
              setForgotEmail("");
              setStep("forgotPassword");
            }}>Forgot password?</button>

          </form>
          <div className="auth-trust-row"><span>🔒 JWT-protected session</span><span>👤 Multi-user access</span><span>✓ Role-based workspace</span></div>
          <div className="auth-divider">New applicant?</div>
          <button className="secondary-button full-width" type="button" onClick={() => {
            clearMessages();
            setRegisterPasswordError("");
            setRegisterConfirmPassword("");
            setRegisterPasswordVisible(false);
            setRegisterConfirmPasswordVisible(false);
            setStep("register");
          }}>Create an applicant account</button>
        </section>

        <div className="public-footer"><span>PropertySetu · Academic demonstration</span><span>Do not use real identity documents in the demo.</span></div>
      </main>
    );
  }

  if (step === "verify" && !officerMode) {
    return (
      <main className="app auth-page">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span><span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
        </header>

        <section className="login-intro">
          <div>
            <p className="eyebrow">ACCOUNT VERIFICATION</p>
            <h1>Verify your email and mobile number.</h1>
            <p>Two independent OTP checks are handled by MSG91 to confirm the email and mobile contacts before password login is enabled.</p>
          </div>
          <div className="mini-notice"><strong>Security checkpoint</strong><span>Both channels must be verified before password login is enabled.</span></div>
        </section>

        {message && <div className="message success" role="status">{message}</div>}
        {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
        {error && <div className="message error" role="alert">{error}</div>}

        <section className="card verification-card">
          <div className="verification-identity">
            <span className="step-icon">✓</span>
            <div><p className="eyebrow">ACCOUNT</p><h2>{verificationUsername}</h2><p className="muted">Enter the 6-digit code exactly as received. Codes expire according to MSG91.</p></div>
          </div>

          <div className="verification-grid">
            {[
              ["EMAIL", "Email verification", `We sent a code to ${maskEmail(verificationEmail)}.`],
              ["PHONE", "Mobile verification", `We sent a code to ${maskPhone(verificationPhone)}.`]
            ].map(([channel, title, description]) => (
              <article className={verificationState[channel] ? "otp-card verified" : "otp-card"} key={channel}>
                <div className="otp-card-heading">
                  <span>{verificationState[channel] ? "✓" : channel === "EMAIL" ? "@" : "⌕"}</span>
                  <div><b>{title}</b><small>{verificationState[channel] ? "Verified" : description}</small>{!verificationState[channel] && demoOtpCodes[channel] && <strong className="demo-otp-code">Academic demo OTP: {demoOtpCodes[channel]}</strong>}</div>
                </div>
                {!verificationState[channel] && (
                  <>
                    <label htmlFor={`otp-${channel.toLowerCase()}`}>One-time password</label>
                    <input
                      id={`otp-${channel.toLowerCase()}`}
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={10}
                      value={verificationCodes[channel]}
                      onChange={event => setVerificationCodes(previous => ({ ...previous, [channel]: event.target.value.replace(/\D/g, "") }))}
                      placeholder="Enter OTP"
                    />
                    <div className="otp-actions">
                      <button type="button" onClick={() => verifyMsg91Otp(channel)} disabled={busy}>Verify {channel === "EMAIL" ? "email" : "mobile"}</button>
                      <button type="button" className="secondary-button" onClick={() => resendMsg91Otp(channel)} disabled={busy || otpCooldowns[channel] > 0}>{otpCooldowns[channel] > 0 ? `Resend in ${otpCooldowns[channel]}s` : "Resend code"}</button>
                    </div>
                  </>
                )}
              </article>
            ))}
          </div>

          <div className="verification-rule">
            <span>01</span><b className={verificationState.EMAIL ? "verified-text" : ""}>{verificationState.EMAIL ? "✓ Email verified" : "Email verification"}</b>
            <i>+</i>
            <span>02</span><b className={verificationState.PHONE ? "verified-text" : ""}>{verificationState.PHONE ? "✓ Mobile verified" : "Mobile verification"}</b>
            <i>→</i><strong>Login enabled</strong>
          </div>

          <button type="button" className="secondary-button full-width" onClick={() => { clearMessages(); setStep("login"); }} disabled={busy}>Back to sign in</button>
        </section>

        <div className="public-footer"><span>PropertySetu · Academic demonstration</span><span>Contact verification protects account access.</span></div>
      </main>
    );
  }

  if (step === "forgotPassword" && !officerMode) {
    return (
      <main className="app auth-page">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span><span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
          <button className="nav-link" type="button" onClick={() => { clearMessages(); setStep("login"); }}>← Back to sign in</button>
        </header>

        <section className="login-intro">
          <div><p className="eyebrow">ACCOUNT RECOVERY</p><h1>Reset your password securely.</h1><p>We will send a one-time code to the email address on the account.</p></div>
          <div className="mini-notice"><strong>Privacy-aware recovery</strong><span>The response does not reveal whether an email is registered.</span></div>
        </section>

        {message && <div className="message success" role="status">{message}</div>}
        {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
        {error && <div className="message error" role="alert">{error}</div>}

        <section className="card auth-card">
          <form onSubmit={requestPasswordReset}>
            <div className="form-section-heading"><span className="step-icon">01</span><div><h2>Find your account</h2><p className="muted">Enter the email you used during registration.</p></div></div>
            <label htmlFor="forgot-email">Email address <span>*</span></label>
            <input id="forgot-email" type="email" autoComplete="email" value={forgotEmail} onChange={event => setForgotEmail(event.target.value)} required />
            <small className="field-example">Example: rahul.sharma@example.com</small>
            <button type="submit" disabled={busy}>{busy ? "Sending verification…" : "Send reset OTP"}</button>
          </form>
        </section>
      </main>
    );
  }

  if (step === "resetPassword" && !officerMode) {
    return (
      <main className="app auth-page">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span><span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
        </header>

        <section className="login-intro">
          <div><p className="eyebrow">PASSWORD RECOVERY</p><h1>Enter the reset code.</h1><p>Use the OTP sent to your email, then choose a new password.</p></div>
        </section>

        {message && <div className="message success" role="status">{message}</div>}
        {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
        {error && <div className="message error" role="alert">{error}</div>}

        <section className="card auth-card">
          <div className="form-section-heading"><span className="step-icon">02</span><div><h2>Verify and reset</h2><p className="muted">Account: {forgotEmail}</p></div></div>
          {!resetAccessToken ? (
            <>
              <label htmlFor="reset-code">Email OTP <span>*</span></label>
              <input id="reset-code" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={resetCode} onChange={event => setResetCode(event.target.value.replace(/\D/g, ""))} placeholder="Enter 6-digit OTP" />
              {demoOtpCodes.RESET && <div className="decision-note"><b>Academic demo OTP</b><span>{demoOtpCodes.RESET}</span></div>}
              <button type="button" onClick={verifyPasswordResetOtp} disabled={busy}>{busy ? "Verifying…" : "Verify email OTP"}</button>
              <button type="button" className="secondary-button" onClick={resendPasswordResetOtp} disabled={busy}>Send another code</button>
            </>
          ) : (
            <div className="decision-note"><b>✓ Email verified</b><span>{MSG91_WIDGET_ID && MSG91_WIDGET_TOKEN ? "The verified email has been confirmed by MSG91. Choose a new password to complete recovery." : "The demo email OTP has been confirmed. Choose a new password to complete recovery."}</span></div>
          )}
          <label htmlFor="reset-password">New password <span>*</span></label>
          <input id="reset-password" type="password" autoComplete="new-password" minLength={6} maxLength={100} value={newPassword} onChange={event => setNewPassword(event.target.value)} required />
          <button type="button" onClick={submitPasswordReset} disabled={busy || !resetAccessToken}>{busy ? "Resetting password…" : "Reset password"}</button>
          <button type="button" className="secondary-button" onClick={() => { clearMessages(); setResetCode(""); setResetAccessToken(""); setStep("forgotPassword"); }} disabled={busy}>Use another email</button>
        </section>
      </main>
    );
  }

  if (step === "register" && !officerMode) {
    return (
      <main className="app auth-page">
        <header className="site-nav">
          <button className="brand-button" type="button" onClick={() => setStep("home")} aria-label="PropertySetu home">
            <span className="brand-mark">P</span>
            <span><b>PropertySetu</b><small>Academic project</small></span>
          </button>
          <button className="nav-link" type="button" onClick={() => { clearMessages(); setStep("login"); }}>← Back to sign in</button>
        </header>

        <section className="login-intro">
          <div>
            <p className="eyebrow">APPLICANT ONBOARDING</p>
            <h1>Create your PropertySetu applicant account.</h1>
            <p>One account gives you a place to prepare your academic property application, upload demo documents and follow its existing review status.</p>
          </div>
          <div className="mini-notice"><strong>Academic demonstration</strong><span>Use demo information only. This is not an official government registration portal.</span></div>
        </section>

        {message && <div className="message success" role="status">{message}</div>}
        {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
        {error && <div className="message error" role="alert">{error}</div>}

        <section className="card auth-card">
          <form onSubmit={register} aria-busy={busy}>
            <div className="form-section-heading"><span className="step-icon">01</span><div><h2>Applicant account</h2><p className="muted">Create your sign-in details. Your account is saved immediately and you can continue straight to the property workflow.</p></div></div>
            <div className="decision-note"><b>Before you begin</b><span>Your email and mobile number are saved with your PropertySetu account for contact and recovery. Account creation does not require OTP verification; payment is handled separately in Razorpay Test Mode. Keep real identity documents out of this academic demo.</span></div>

            <div className="field-grid two">
              <div className="field">
                <label htmlFor="register-username">Username <span>*</span></label>
                <input id="register-username" name="username" autoComplete="username" value={registerForm.username} onChange={e => update(setRegisterForm, "username", e.target.value)} required />
                <small className="field-example">Example: rahul.sharma</small>
              </div>
              <div className="field">
                <label htmlFor="register-email">Email <span>*</span></label>
                <input id="register-email" name="email" type="email" autoComplete="email" value={registerForm.email} onChange={e => update(setRegisterForm, "email", e.target.value)} required />
                <small className="field-example">Example: rahul.sharma@example.com</small>
              </div>
            </div>

            <div className="field-grid two">
              <div className="field">
                <label htmlFor="register-phone">Mobile number <span>*</span></label>
                <input id="register-phone" name="phone" type="tel" inputMode="numeric" autoComplete="tel" maxLength={10} value={registerForm.phone} onChange={e => update(setRegisterForm, "phone", e.target.value.replace(/\D/g, ""))} required />
                <small className="field-example">Example: 9876543210 · Saved with your account</small>
              </div>
              <div className="field">
                <label htmlFor="register-password">Password <span>*</span></label>
                <div className="password-field">
                  <input id="register-password" name="password" autoComplete="new-password" type={registerPasswordVisible ? "text" : "password"} value={registerForm.password} minLength={6} maxLength={100} onChange={e => { const value = e.target.value; update(setRegisterForm, "password", value); if (value.length > 100) setRegisterPasswordError("Password cannot exceed 100 characters."); else if (value.length > 0 && value.length < 6) setRegisterPasswordError("Password must be at least 6 characters."); else if (registerConfirmPassword && value !== registerConfirmPassword) setRegisterPasswordError("Passwords do not match."); else setRegisterPasswordError(""); }} required />
                  <button type="button" className="password-toggle" onClick={() => setRegisterPasswordVisible(previous => !previous)}>{registerPasswordVisible ? "Hide" : "Show"}</button>
                </div>
                <small className="field-example">Use 6–100 characters · {registerForm.password.length}/100</small>
              </div>
            </div>

            <div className="password-check"><b>Password requirements</b><span className={registerForm.password.length >= 6 ? "valid" : ""}>✓ At least 6 characters</span><span className={registerForm.password.length <= 100 ? "valid" : ""}>✓ Maximum 100 characters</span></div>

            <div className="field">
              <label htmlFor="register-confirm-password">Confirm password <span>*</span></label>
              <div className="password-field">
                <input id="register-confirm-password" name="confirmPassword" autoComplete="new-password" type={registerConfirmPasswordVisible ? "text" : "password"} value={registerConfirmPassword} maxLength={100} onChange={e => { const value = e.target.value; setRegisterConfirmPassword(value); if (value && registerForm.password !== value) setRegisterPasswordError("Passwords do not match."); else if (registerForm.password.length > 0 && registerForm.password.length < 6) setRegisterPasswordError("Password must be at least 6 characters."); else setRegisterPasswordError(""); }} required />
                <button type="button" className="password-toggle" onClick={() => setRegisterConfirmPasswordVisible(previous => !previous)}>{registerConfirmPasswordVisible ? "Hide" : "Show"}</button>
              </div>
              <small className={`field-example ${registerConfirmPassword && registerForm.password === registerConfirmPassword ? "match" : ""}`}>{registerConfirmPassword && registerForm.password === registerConfirmPassword ? "✓ Passwords match" : "Example: re-enter the same password"}</small>
            </div>

            {registerPasswordError && <p className="validation-hint" role="alert">{registerPasswordError}</p>}

            <button type="submit" disabled={busy || registerForm.password.length < 6 || registerForm.password.length > 100 || registerForm.password !== registerConfirmPassword}>
              {busy ? "Creating account…" : "Create applicant account"}
            </button>
            <button type="button" className="secondary-button" onClick={() => { clearMessages(); setRegisterPasswordError(""); setRegisterConfirmPassword(""); setRegisterPasswordVisible(false); setRegisterConfirmPasswordVisible(false); setStep("login"); }} disabled={busy}>Back to sign in</button>
          </form>

          <div className="auth-trust-row"><span>🔒 Protected sign-in session</span><span>👤 Applicant workspace</span><span>✓ Guided workflow</span></div>
        </section>
        <div className="public-footer"><span>PropertySetu · Academic demonstration</span><span>No official registration is performed here.</span></div>
      </main>
    );
  }
  if (officerMode) {
    return (
      <main className="app">
        <header className="header">
          <div>
            <p className="eyebrow">PROPERTYSETU · ROLE-BASED ADMINISTRATION</p>
            <h1>{user?.role === "ADMIN" ? "Administration & officer review" : "Officer verification workspace"}</h1>
            <p className="subtitle">{user?.role === "ADMIN" ? "Manage application review and control user access from one protected workspace." : "Review paid applications and complete verification."}</p>
          </div>
          <div>
            <div className="status">{user ? `${user.username} · ${user.role}` : "Officer Portal"}</div>
            <button className="link-button" onClick={logout}>Log out</button>
          </div>
        </header>

        {message && <div className="message success">{message}</div>}
        {error && <div className="message error">{error}</div>}

        {user?.role === "ADMIN" && (
          <section className="card admin-user-panel">
            <div className="timeline-heading">
              <div>
                <p className="eyebrow">ADMIN USER MANAGEMENT</p>
                <h2>Users & access control</h2>
                <p className="muted">Manage applicant and officer accounts, account status and role permissions. Passwords are never displayed.</p>
              </div>
              <button type="button" className="secondary-button" onClick={loadAdminUsers} disabled={adminUsersLoading}>
                {adminUsersLoading ? "Refreshing…" : "Refresh users"}
              </button>
            </div>

            <form className="admin-create-form" onSubmit={createAdminManagedUser}>
              <div className="field-grid two">
                <div className="field"><label>Username</label><input value={adminUserForm.username} onChange={e => setAdminUserForm(p => ({...p, username:e.target.value}))} /></div>
                <div className="field"><label>Email</label><input type="email" value={adminUserForm.email} onChange={e => setAdminUserForm(p => ({...p, email:e.target.value}))} /></div>
                <div className="field"><label>Mobile</label><input inputMode="numeric" value={adminUserForm.phone} onChange={e => setAdminUserForm(p => ({...p, phone:e.target.value.replace(/\\D/g, "")}))} maxLength={10} /></div>
                <div className="field"><label>Temporary password</label><input type="password" value={adminUserForm.password} onChange={e => setAdminUserForm(p => ({...p, password:e.target.value}))} /></div>
              </div>
              <div className="admin-create-actions">
                <select value={adminUserForm.role} onChange={e => setAdminUserForm(p => ({...p, role:e.target.value}))}>
                  <option value="OFFICER">Officer</option>
                  <option value="ADMIN">Admin</option>
                  <option value="APPLICANT">Applicant</option>
                </select>
                <button type="submit" disabled={busy}>{busy ? "Creating…" : "Create user"}</button>
              </div>
            </form>

            {adminUsersLoading && <p className="muted">Loading user accounts from the configured database…</p>}
            {!adminUsersLoading && adminUsers.length === 0 && <p className="muted">No user accounts found.</p>}
            {!adminUsersLoading && adminUsers.length > 0 && (
              <div className="admin-user-list">
                {adminUsers.map(account => (
                  <div className="admin-user-row" key={account.id}>
                    <div className="admin-user-identity">
                      <strong>{account.username}</strong>
                      <span>{account.email}</span>
                      <small>{account.phone || "No mobile"} · ID {account.id} · Created {account.createdAt || "recorded in database"}</small>
                    </div>
                    <div className="admin-user-controls">
                      <select value={account.role} onChange={e => updateAdminManagedUser(account.id, { role: e.target.value })}>
                        <option value="APPLICANT">Applicant</option>
                        <option value="OFFICER">Officer</option>
                        <option value="ADMIN">Admin</option>
                      </select>
                      <button type="button" className={account.active ? "status-toggle active" : "status-toggle"} onClick={() => updateAdminManagedUser(account.id, { active: !account.active })}>
                        {account.active ? "Active" : "Inactive"}
                      </button>
                      <button type="button" className={account.emailVerified ? "status-toggle active" : "status-toggle"} onClick={() => updateAdminManagedUser(account.id, { emailVerified: !account.emailVerified })}>
                        {account.emailVerified ? "Email ✓" : "Email pending"}
                      </button>
                      <button type="button" className={account.phoneVerified ? "status-toggle active" : "status-toggle"} onClick={() => updateAdminManagedUser(account.id, { phoneVerified: !account.phoneVerified })}>
                        {account.phoneVerified ? "Mobile ✓" : "Mobile pending"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        <section className="dashboard-grid">
          <div className="card application-list">
            <h2>Applications</h2>
            <button className="secondary-button" onClick={openOfficerDashboard}>Refresh applications</button>
            <input
              placeholder="Search application, applicant or property"
              value={applicationSearch}
              onChange={e => setApplicationSearch(e.target.value)}
            />
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
              <option value="ALL">All statuses</option>
              <option value="PAID">Paid</option>
              <option value="UNDER_VERIFICATION">Under verification</option>
              <option value="NEEDS_CORRECTION">Needs correction</option>
              <option value="RESUBMITTED">Resubmitted</option>
              <option value="SUBMITTED">Submitted</option>
              <option value="COMPLETED">Completed</option>
              <option value="REJECTED">Rejected</option>
            </select>
            <select value={applicationSort} onChange={e => setApplicationSort(e.target.value)} aria-label="Sort applications">
              <option value="NEWEST">Newest first</option>
              <option value="OLDEST">Oldest first</option>
              <option value="STATUS">Sort by status</option>
            </select>
            {visibleApplications.length === 0 && <p className="muted">No matching applications found.</p>}
            {visibleApplications.map(item => (
              <button
                className={selectedApplication?.id === item.id ? "application-row selected" : "application-row"}
                key={item.id}
                onClick={async () => {
                  setSelectedApplication(item);
                  setAssignmentForm(previous => ({
                    ...previous,
                    officerId: item.assignedOfficerId ? String(item.assignedOfficerId) : ""
                  }));
                  await loadAuditHistory(item.id);
                  try {
                    setSelectedDocuments(await request(`/api/applications/${item.id}/documents`));
                  } catch (err) {
                    setError(err.message);                  }
                }}
              >
                <strong>{item.applicationNumber}</strong>
                <span>{item.applicantUsername || "Applicant"}</span>
                <span className="badge">{item.status}</span>
              </button>
            ))}
          </div>

          <div className="card">
            <h2>Review application</h2>
            {!selectedApplication && <p className="muted">Select an application from the list.</p>}
            {selectedApplication && (
              <>
                <div className="summary">
                  <p><b>Application:</b> {selectedApplication.applicationNumber}</p>
                  <p><b>Applicant:</b> {selectedApplication.applicantUsername}</p>
                  <p><b>Property:</b> {selectedApplication.propertyNumber}</p>
                  <p><b>Status:</b> {selectedApplication.status}</p>
                  <p><b>Purpose:</b> {selectedApplication.purpose}</p>
                  <p><b>Created:</b> {selectedApplication.createdAt ? new Date(selectedApplication.createdAt).toLocaleString("en-IN") : "-"}</p>
                </div>
                {user?.role === "ADMIN" && (
                  <form className="admin-create-form" onSubmit={assignOfficerToApplication}>
                    <p className="eyebrow">CASE ASSIGNMENT</p>
                    <h3>Assign an officer</h3>
                    <p className="muted">Only active OFFICER accounts can receive paid or review-stage applications. Reassignment is recorded in the audit history.</p>
                    <div className="field-grid two">
                      <div className="field">
                        <label htmlFor="assigned-officer">Assigned officer</label>
                        <select id="assigned-officer" value={assignmentForm.officerId} onChange={event => setAssignmentForm(previous => ({ ...previous, officerId: event.target.value }))} required>
                          <option value="">Choose an officer</option>
                          {adminUsers.filter(account => account.role === "OFFICER" && account.active).map(account => (
                            <option key={account.id} value={account.id}>{account.username} · {account.email}</option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <label htmlFor="assignment-reason">Assignment / reassignment reason</label>
                        <input id="assignment-reason" value={assignmentForm.reason} onChange={event => setAssignmentForm(previous => ({ ...previous, reason: event.target.value }))} maxLength={500} required />
                      </div>
                    </div>
                    <p className="muted">Current assignment: {selectedApplication.assignedOfficerUsername || "Not assigned"}</p>
                    <button type="submit" disabled={busy || !["PAID", "UNDER_VERIFICATION", "NEEDS_CORRECTION", "RESUBMITTED"].includes(selectedApplication.status)}>
                      {busy ? "Saving…" : selectedApplication.assignedOfficerId ? "Reassign officer" : "Assign officer"}
                    </button>
                  </form>
                )}
                <div className="officer-documents">
                  <h3>Document review</h3>
                  <p className="muted">Verify every required document before completing this application.</p>
                  {selectedDocuments.length === 0 && <p className="muted">No documents uploaded.</p>}
                  {selectedDocuments.map(document => (
                    <div className="officer-document-row" key={document.id}>
                      <span>
                        <b>{document.documentType.replaceAll("_", " ")} · v{document.versionNumber || 1}</b>
                        <small>{document.fileName}</small>
                        {document.reviewRemarks && <small>Review note ({document.reviewedByUsername || "Officer"}): {document.reviewRemarks}</small>}
                        {document.reviewedAt && <small>Reviewed {new Date(document.reviewedAt).toLocaleString("en-IN")}</small>}
                        <button type="button" className="document-link" onClick={() => openProtectedDocument(selectedApplication.id, document.id)}>Open protected file</button>
                      </span>
                      {user?.role === "OFFICER" ? (
                        <select
                          value={document.status}
                          disabled={!["PAID", "UNDER_VERIFICATION", "RESUBMITTED"].includes(selectedApplication.status) || document.status === "SUPERSEDED"}
                          onChange={async event => {
                            const nextStatus = event.target.value;
                            if (nextStatus === "REJECTED" && !remarks.trim()) {
                              setError("Enter a clear correction reason in Officer review remarks before rejecting this document.");
                              return;
                            }
                            try {
                              const query = new URLSearchParams({ status: nextStatus });
                              if (remarks.trim()) query.set("remarks", remarks.trim());
                              const updated = await request(`/api/applications/${selectedApplication.id}/documents/${document.id}/review?${query.toString()}`, { method: "POST" });
                              setSelectedDocuments(previous => previous.map(item => item.id === updated.id ? updated : item));
                              if (updated.status === "REJECTED") {
                                const refreshedApplications = await request("/api/applications");
                                setApplications(refreshedApplications);
                                const current = refreshedApplications.find(item => item.id === selectedApplication.id);
                                if (current) setSelectedApplication(current);
                              }
                              setMessage(updated.status === "REJECTED"
                                ? "Correction requested. The applicant can upload a new version."
                                : "Document review status updated.");
                            } catch (err) {
                              setError(err.message);
                            }
                          }}
                        >
                          <option value="UPLOADED">Uploaded</option>
                          <option value="UNDER_REVIEW">Under review</option>
                          <option value="VERIFIED">Verified</option>
                          <option value="REJECTED">Request correction</option>
                          <option value="SUPERSEDED" disabled>Superseded version</option>
                        </select>
                      ) : (
                        <span className="badge">{document.status} · v{document.versionNumber || 1}</span>
                      )}
                    </div>
                  ))}
                </div>
                <div className="audit-panel">
                  <div className="audit-heading">
                    <h3>Accountability history</h3>
                    <span>{auditEvents.length} event{auditEvents.length === 1 ? "" : "s"}</span>
                  </div>
                  {auditEvents.length === 0 ? (
                    <p className="muted">No recorded history for this application.</p>
                  ) : (
                    <div className="audit-list">
                      {auditEvents.map(event => (
                        <div className="audit-event" key={event.id}>
                          <div>
                            <strong>{event.action.replaceAll("_", " ")}</strong>
                            <small>{event.actorUsername || "System"} · {event.actorRole || "SYSTEM"}</small>
                          </div>
                          <time>{event.occurredAt ? new Date(event.occurredAt).toLocaleString("en-IN") : "-"}</time>
                          {event.details && <p>{event.details}</p>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                {user?.role === "OFFICER" && ["PAID", "UNDER_VERIFICATION", "RESUBMITTED"].includes(selectedApplication.status) && (
                  <>
                    <label htmlFor="officer-remarks">Officer review remarks / correction reason</label>
                    <textarea id="officer-remarks" value={remarks} onChange={e => setRemarks(e.target.value)} maxLength={2000} placeholder="Explain the decision or identify the exact correction required." />
                    <div className="action-row">
                      <button onClick={() => verifySelected("VERIFIED")} disabled={!remarks.trim() || !["IDENTITY_PROOF", "ADDRESS_PROOF", "PROPERTY_DOCUMENT"].every(type => selectedDocuments.some(document => document.documentType === type && document.status === "VERIFIED"))}>Complete verification</button>
                      <button className="reject-button" onClick={() => verifySelected("REJECTED")} disabled={!remarks.trim()}>Reject application</button>
                    </div>
                  </>
                )}
                {user?.role === "OFFICER" && selectedApplication.status === "NEEDS_CORRECTION" && (
                  <div className="message">
                    Waiting for the applicant to replace the rejected document version and resubmit. Refresh applications after the applicant resubmits.
                  </div>
                )}
                {user?.role === "ADMIN" && (
                  <div className="message">Administration can assign and monitor cases. Document decisions must be made by the assigned officer.</div>
                )}
                {selectedApplication.status === "COMPLETED" && (
                  <div className="message success">
                    Academic workflow completed. This is not an official government registration certificate.
                  </div>
                )}
              </>
            )}
          </div>
        </section>

      </main>
    );
  }

  return (
    <>
      <main className="app">
      <header className="header">
        <div>
          <p className="eyebrow">PROPERTYSETU · ACADEMIC APPLICATION WORKFLOW</p>
          <h1>Complete your application step by step.</h1>
          <p className="subtitle">
            Property details, supporting documents, review and test-mode payment in one guided workspace.
          </p>
        </div>
        <div>
          <div className="status">{user ? `${user.username} · Applicant` : "Applicant workspace"}</div>
          <button className="link-button" onClick={logout}>Log out</button>
        </div>
      </header>

      <section className="account-security-card" aria-label="Account verification status">
        <div>
          <p className="eyebrow">ACCOUNT SECURITY</p>
          <h3>Contact verification</h3>
          <p className="muted">Your registered email and mobile number are stored with your account for contact and password-recovery purposes. Registration does not require OTP.</p>
        </div>
        <div className="security-badges">
          <span className="verified">✉ Email on account</span>
          <span className="verified">⌕ Mobile on account</span>
          <span className="verified">🔐 JWT session</span>
        </div>
      </section>

      <section className="applicant-status-bar">
        <div>
          <p className="eyebrow">APPLICATION CONTROL CENTRE</p>
          <h2>{application?.applicationNumber || "Start a guided application"}</h2>
          <p className="muted">{application ? "Your application remains visible as it moves through preparation, payment and officer review." : "Complete the guided steps below. You can return to this workspace while preparing your submission."}</p>
        </div>
        <div className="status-control">
          <span className="badge">{application?.status || "DRAFT"}</span>
          <button type="button" className="secondary-button" onClick={refreshApplicantApplications}>Refresh status</button>
        </div>
      </section>

      {applicantApplications.length > 0 && (
        <section className="application-timeline-card">
          <div className="timeline-heading">
            <div><h3>My applications</h3><p className="muted">A transparent view of your submitted records.</p></div>
            <span>{applicantApplications.length} record{applicantApplications.length === 1 ? "" : "s"}</span>
          </div>
          <div className="applicant-application-list">
            {applicantApplications.map(item => (
              <button type="button" className={application?.id === item.id ? "applicant-application active" : "applicant-application"} key={item.id} onClick={() => selectApplicantApplication(item)}>
                <span><b>{item.applicationNumber}</b><small>{item.propertyNumber || "Property record"}</small></span>
                <strong>{item.status}</strong>
              </button>
            ))}
          </div>
        </section>
      )}

      <section className="card application-history-panel">
        <div className="timeline-heading">
          <div>
            <p className="eyebrow">APPLICATION HISTORY</p>
            <h3>Find an application or check a payment</h3>
            <p className="muted">Search the application records available to your signed-in account by registration/application number or property reference.</p>
          </div>
          <span>{applicantApplications.length} record{applicantApplications.length === 1 ? "" : "s"}</span>
        </div>
        <div className="field">
          <label htmlFor="application-lookup">Registration / application number</label>
          <input id="application-lookup" value={applicationLookup} onChange={event => setApplicationLookup(event.target.value)} placeholder="Example: REG-89BF4792" />
          <small className="field-example">Your search is limited to applications accessible to your account.</small>
        </div>
        <div className="applicant-application-list">
          {applicantApplications.filter(item => {
            const query = applicationLookup.trim().toLowerCase();
            return !query || item.applicationNumber?.toLowerCase().includes(query) || item.propertyNumber?.toLowerCase().includes(query);
          }).map(item => (
            <button type="button" className={application?.id === item.id ? "applicant-application active" : "applicant-application"} key={`lookup-${item.id}`} onClick={() => selectApplicantApplication(item)}>
              <span><b>{item.applicationNumber}</b><small>{item.propertyNumber || "Property record"}</small></span>
              <strong>{item.status}</strong>
            </button>
          ))}
        </div>
        {applicantApplications.length > 0 && applicantApplications.filter(item => {
          const query = applicationLookup.trim().toLowerCase();
          return !query || item.applicationNumber?.toLowerCase().includes(query) || item.propertyNumber?.toLowerCase().includes(query);
        }).length === 0 && <p className="muted">No matching application was found in this account.</p>}
      </section>

      <section className="card application-history-panel">
        <div className="timeline-heading">
          <div>
            <p className="eyebrow">PAYMENT HISTORY</p>
            <h3>Recent payment records</h3>
            <p className="muted">Payment information is loaded from the existing PropertySetu payment records.</p>
          </div>
          <button type="button" className="secondary-button" onClick={() => loadPaymentHistory(applicantApplications)} disabled={paymentHistoryLoading}>
            {paymentHistoryLoading ? "Checking…" : "Refresh payments"}
          </button>
        </div>
        {paymentHistoryLoading && <p className="muted">Checking recent application payment records…</p>}
        {!paymentHistoryLoading && paymentHistory.length === 0 && <p className="muted">No payment record is available yet.</p>}
        {!paymentHistoryLoading && paymentHistory.length > 0 && (
          <div className="applicant-application-list">
            {paymentHistory.slice(0, 8).map(item => (
              <button type="button" className="applicant-application" key={`payment-${item.id || item.application?.id}` } onClick={() => selectApplicantApplication(item.application)}>
                <span>
                  <b>{item.application?.applicationNumber || "Application"}</b>
                  <small>₹{Number(item.amount || 0).toFixed(2)} · {item.paymentStatus || "UNKNOWN"}</small>
                </span>
                <strong>{item.signatureVerified ? "VERIFIED" : item.paymentStatus || "PENDING"}</strong>
              </button>
            ))}
          </div>
        )}
      </section>

      {application && (
        <section className="card application-history-panel" aria-label="Application timeline">
          <div className="timeline-heading">
            <div>
              <p className="eyebrow">APPLICATION MEMORY</p>
              <h3>What has happened so far</h3>
              <p className="muted">A timeline built from recorded application events. It does not claim verification that has not happened.</p>
            </div>
            <span>{auditEvents.length} event{auditEvents.length === 1 ? "" : "s"}</span>
          </div>
          {auditEvents.length === 0 ? (
            <p className="muted">No application events have been recorded yet.</p>
          ) : (
            <div className="audit-list">
              {auditEvents.map(event => (
                <div className="audit-event" key={`applicant-audit-${event.id}`}>
                  <div>
                    <strong>{event.action.replaceAll("_", " ")}</strong>
                    <small>{event.actorRole || "SYSTEM"}</small>
                  </div>
                  <time>{event.occurredAt ? new Date(event.occurredAt).toLocaleString("en-IN") : "-"}</time>
                  {event.details && <p>{event.details}</p>}
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {property && (
        <section className="property-identity-card" aria-label="Current property record">
          <div className="property-identity-main">
            <div className="property-id-icon">⌂</div>
            <div>
              <p className="eyebrow">PROPERTYSETU PROPERTY RECORD</p>
              <h3>{property.propertyNumber || "Saved property"}</h3>
              <p className="muted">This is the property record currently connected to your application. Your account controls access to its details.</p>
            </div>
          </div>
          <div className="property-identity-grid">
            <span><small>Type</small><b>{property.propertyType || "Not specified"}</b></span>
            <span><small>Area</small><b>{property.area ? `${property.area} sq. units` : "Not specified"}</b></span>
            <span><small>Owner reference</small><b>{maskValue(owner?.identityNumber, 4)}</b></span>
            <span><small>Application</small><b>{application?.applicationNumber || "Not started"}</b></span>
          </div>
        </section>
      )}

      <section className="progress-shell" aria-label="Application progress">
        <div className="progress-heading"><div><p className="eyebrow">APPLICATION PROGRESS</p><h2>{applicationProgress() === 7 ? "Application complete" : `Step ${applicationProgress()} of 7`}</h2></div><span>{Math.round((applicationProgress() / 7) * 100)}%</span></div>
        <div className="progress-bar"><span style={{ width: `${Math.round((applicationProgress() / 7) * 100)}%` }} /></div>
        <div className="compact-progress">
          {["Owner", "Property", "Location", "Application", "Documents", "Review", "Payment"].map((label, index) => {
            const currentIndex = applicationProgress() - 1;
            return <span key={label} className={index < currentIndex || applicationProgress() === 7 ? "done" : index === currentIndex ? "current" : "upcoming"}><i>{index < currentIndex || applicationProgress() === 7 ? "✓" : index + 1}</i>{label}</span>;
          })}
        </div>
      </section>

      <section className="academic-notice compact-notice"><div className="notice-icon">i</div><div><strong>Academic demonstration</strong><p>This is a student project, not an official government registration portal. Payment is test-mode only.</p></div></section>

      {message && <div className="message success" role="status">{message}</div>}
      {validationErrors.length > 0 && <div className="validation-summary" role="alert"><strong>There is a problem</strong><ul>{validationErrors.map((item, index) => <li key={index}>{item}</li>)}</ul></div>}
      {error && <div className="message error" role="alert">{error}</div>}

      <section className="readiness-card">
        <div>
          <p className="eyebrow">APPLICATION READINESS</p>
          <h3>{applicationProgress()} of 7 sections complete</h3>
          <p className="muted">{applicationProgress() === 7 ? "Your application and test-mode payment are complete." : "Complete each section in order. Your saved records remain available after you sign in again."}</p>
        </div>        <div className="readiness-steps">
          {["Owner", "Property", "Location", "Application", "Documents", "Review", "Payment"].map((label, index) => {
            const currentIndex = applicationProgress() - 1;
            const complete = applicationProgress() === 7 || index < currentIndex;
            return <span key={label} className={complete ? "ready" : index === currentIndex ? "active" : "future"}><i>{complete ? "✓" : index + 1}</i>{label}</span>;
          })}        </div>
      </section>

      <section className="companion-card" aria-label="Application guide">
        <div className="companion-icon">✦</div>
        <div>
          <p className="eyebrow">APPLICATION GUIDE</p>
          <h3>{companionGuidance()[0]}</h3>
          <p>{companionGuidance()[1]}</p>
        </div>
        <span className="companion-next">{applicationProgress() === 7 ? "Workflow complete" : "Continue with the section below"}</span>
      </section>

      <section className="card">
        {step === "owner" && (
          <form onSubmit={createOwner}>
            <div className="form-section-heading"><span className="step-icon">01</span><div><h2>Applicant information</h2><p className="muted">Tell us about the owner associated with this application.</p></div></div>
            <div className="field-grid two">
              <div className="field"><label htmlFor="owner-name">Full name <span>*</span></label><input id="owner-name" placeholder="" value={ownerForm.name} onChange={e => update(setOwnerForm, "name", e.target.value)} required /><small className="field-example">Example: Rahul Sharma</small></div>
              <div className="field"><label htmlFor="owner-phone">Mobile number <span>*</span></label><input id="owner-phone" type="tel" inputMode="numeric" maxLength={10} placeholder="" value={ownerForm.phone} onChange={e => update(setOwnerForm, "phone", e.target.value.replace(/\D/g, ""))} required /><small className="field-example">Example: 9876543210</small></div>
            </div>
            <div className="field"><label htmlFor="owner-address">Address <span>*</span></label><textarea id="owner-address" placeholder="" value={ownerForm.address} onChange={e => update(setOwnerForm, "address", e.target.value)} required /><small className="field-example">Example: 42, Lakeview Avenue, Sector 15</small></div>
            <div className="field"><label htmlFor="owner-identity">Identity/reference number <span>*</span></label><input id="owner-identity" placeholder="" value={ownerForm.identityNumber} onChange={e => update(setOwnerForm, "identityNumber", e.target.value)} required /><small className="field-example">Example: ID-2026-001</small></div>
            <div className="form-navigation"><span className="step-helper">Your information is used only for this application workflow.</span><button type="submit" disabled={busy}>{busy ? "Saving applicant…" : "Save & continue"}</button></div>
          </form>
        )}

        {step === "property" && (
          <>
            {owner && <div className="owner-found-panel">
              <div className="owner-found-icon">✓</div>
              <div>
                <p className="eyebrow">OWNER PROFILE FOUND</p>
                <h3>Welcome back — your owner profile is already saved.</h3>
                <p className="muted">We found your existing profile and loaded it for this workflow. You do not need to create another owner record.</p>
                <div className="owner-found-meta"><span><small>Name</small><b>{owner.name || "Protected"}</b></span><span><small>Mobile</small><b>{maskValue(owner.phone, 4)}</b></span><span><small>Identity</small><b>{maskValue(owner.identityNumber, 4)}</b></span></div>
              </div>
            </div>}
            {properties.length > 0 && <div className="saved-record-panel"><div><p className="eyebrow">SAVED PROPERTY RECORDS</p><h2>Continue with a saved property</h2><p className="muted">Choose a property you already saved instead of creating another record.</p></div>{properties.map(item => (
                <div className="saved-record" key={item.id}>
                  <button type="button" className="saved-record-main" onClick={() => { setProperty(item); setMessage(`Using saved property ${item.propertyNumber}.`); setStep("location"); }}>
                    <span><b>{item.propertyNumber}</b><small>{item.propertyType} · {item.area} sq. units</small></span>
                    <strong>Continue →</strong>
                  </button>
                  <button type="button" className="link-button" onClick={() => {
                    setEditingPropertyId(item.id);
                    setPropertyForm({
                      propertyNumber: item.propertyNumber || "",
                      propertyType: item.propertyType || "",
                      area: item.area || "",
                      description: item.description || ""
                    });
                    setProperty(item);
                    clearMessages();
                  }}>Edit details</button>
                </div>
              ))}</div>}
            {propertyReferenceMatch && <div className="duplicate-awareness-panel" role="status">
              <div className="duplicate-awareness-icon">✓</div>
              <div>
                <strong>Existing property record detected in your account</strong>
                <span><b>{propertyReferenceMatch.propertyNumber}</b> · {propertyReferenceMatch.propertyType || "Property"} · {propertyReferenceMatch.area || "—"} sq. units</span>
                <small>To keep your records clean, continue with the saved property instead of creating a duplicate.</small>
              </div>
              <button type="button" onClick={() => { setProperty(propertyReferenceMatch); setMessage(`Using saved property ${propertyReferenceMatch.propertyNumber}.`); setStep("location"); }}>Use saved record</button>
            </div>}
            <form onSubmit={createProperty}>
              <div className="form-section-heading"><span className="step-icon">02</span><div><h2>{editingPropertyId ? "Edit property details" : "Property details"}</h2><p className="muted">{editingPropertyId ? "Update this saved property while its application remains in draft." : "Add the property information for this application."}</p></div></div>
              <div className="field-grid two">
                <div className="field"><label htmlFor="property-number">Property reference <span>*</span></label><input id="property-number" placeholder="" value={propertyForm.propertyNumber} onChange={e => update(setPropertyForm, "propertyNumber", e.target.value)} required /><small className="field-example">Example: PROP-2026-001</small>{propertyForm.propertyNumber.trim() && !propertyReferenceMatch && <small className="record-check clear">No matching property reference was found in your saved account records.</small>}{propertyReferenceMatch && <small className="record-check match">✓ Matching saved property found — use the existing record above.</small>}</div>
                <div className="field"><label htmlFor="property-type">Property type <span>*</span></label><select id="property-type" value={propertyForm.propertyType} onChange={e => update(setPropertyForm, "propertyType", e.target.value)} required><option value="">Select property type</option><option value="RESIDENTIAL">Residential</option><option value="COMMERCIAL">Commercial</option><option value="AGRICULTURAL">Agricultural</option></select><small className="field-example">Example: Residential</small></div>
              </div>
              <div className="field-grid two">
                <div className="field"><label htmlFor="property-area">Area <span>*</span></label><input id="property-area" type="number" min="1" step="0.01" placeholder="" value={propertyForm.area} onChange={e => update(setPropertyForm, "area", e.target.value)} required /><small className="field-example">Example: 1200 sq. ft.</small></div>
                <div className="field"><label htmlFor="property-description">Description <span>*</span></label><input id="property-description" placeholder="" value={propertyForm.description} onChange={e => update(setPropertyForm, "description", e.target.value)} required /><small className="field-example">Example: 2 BHK residential apartment with parking.</small></div>
              </div>
              <div className="form-navigation"><button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button><button type="submit" disabled={busy}>{busy ? (editingPropertyId ? "Updating property…" : "Saving property…") : (editingPropertyId ? "Update & continue" : "Save & continue")}</button></div>
            </form>
          </>
        )}

        {step === "location" && (
          <form onSubmit={createLocation}>
            <div className="form-section-heading"><span className="step-icon">03</span><div><h2>Property location</h2><p className="muted">Enter the address where the property is located.</p></div></div>
            <div className="field"><label htmlFor="location-address">Address <span>*</span></label><textarea id="location-address" placeholder="" value={locationForm.address} onChange={e => update(setLocationForm, "address", e.target.value)} required /><small className="field-example">Example: 42, Lakeview Avenue, Sector 15</small></div>
            <div className="field-grid two">
              <div className="field"><label htmlFor="location-city">City <span>*</span></label><input id="location-city" placeholder="" value={locationForm.city} onChange={e => update(setLocationForm, "city", e.target.value)} required /><small className="field-example">Example: Nashik</small></div>
              <div className="field"><label htmlFor="location-district">District <span>*</span></label><input id="location-district" placeholder="" value={locationForm.district} onChange={e => update(setLocationForm, "district", e.target.value)} required /><small className="field-example">Example: Nashik</small></div>
              <div className="field"><label htmlFor="location-state">State <span>*</span></label><input id="location-state" placeholder="" value={locationForm.state} onChange={e => update(setLocationForm, "state", e.target.value)} required /><small className="field-example">Example: Maharashtra</small></div>
              <div className="field"><label htmlFor="location-pincode">PIN code <span>*</span></label><input id="location-pincode" inputMode="numeric" maxLength={6} placeholder="" value={locationForm.pincode} onChange={e => update(setLocationForm, "pincode", e.target.value.replace(/\D/g, ""))} required /><small className="field-example">Example: 422001</small></div>
            </div>
            <div className="address-preview"><span>Address preview</span><strong>{[locationForm.address, locationForm.city, locationForm.district, locationForm.state, locationForm.pincode].filter(Boolean).join(", ") || "Your completed property address will appear here."}</strong>{Object.values(locationForm).every(Boolean) && <small>✓ Address details complete</small>}</div>
            <div className="form-navigation"><button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button><button type="submit" disabled={busy}>{busy ? "Saving location…" : "Save & continue"}</button></div>
          </form>
        )}

        {step === "application" && (
          <form onSubmit={createApplication}>
            <div className="form-section-heading"><span className="step-icon">04</span><div><h2>Application details</h2><p className="muted">Choose the closest purpose for this academic demonstration.</p></div></div>
            <div className="field"><label htmlFor="purpose-type">Application purpose <span>*</span></label><select id="purpose-type" value={purposeType} onChange={e => setPurposeType(e.target.value)} required><option value="">Select a purpose</option><option value="Sale / transfer of property">Sale / transfer of property</option><option value="Gift deed">Gift deed</option><option value="Lease / rent agreement">Lease / rent agreement</option><option value="Mortgage / loan document">Mortgage / loan document</option><option value="Power of attorney">Power of attorney</option><option value="Other registration purpose">Other registration purpose</option></select><small className="field-example">Example: Sale / transfer of property</small></div>
            <div className="field"><label htmlFor="purpose-note">Application note</label><textarea id="purpose-note" placeholder="" value={purpose} onChange={e => setPurpose(e.target.value)} maxLength={500} /><small className="field-example">Example: Application for transfer of a residential property.</small></div>
            <div className="decision-note"><b>Before you continue</b><span>PropertySetu is demonstrating the workflow. Confirm transaction-specific requirements, fees, witnesses and documents with the appropriate official source.</span></div>
            <div className="form-navigation"><button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button><button type="submit" disabled={busy}>{busy ? (application?.id ? "Saving application…" : "Creating application…") : (application?.id ? "Save application changes" : "Create application")}</button>
              {application?.id && application.status === "DRAFT" && (
                <button type="button" className="link-button danger-link" onClick={deleteDraftApplication} disabled={busy}>Delete draft application</button>
              )}</div>
          </form>
        )}

        {step === "documents" && (
          <form onSubmit={uploadDocument}>
            <div className="form-section-heading"><span className="step-icon">05</span><div><h2>Supporting documents</h2><p className="muted">Add clear demo files to the categories used by this workflow.</p></div></div>
            <p className="muted">Use synthetic/demo files only. Identity proof, address proof and property document are three separate uploads; one file cannot satisfy all three categories.</p>
            <div className="document-guide">
              <strong>Core workflow checklist</strong>
              <span>1. Identity proof · 2. Address proof · 3. Property document</span>
              <small>Additional documents may apply: witnesses, stamp-duty proof, tax receipts, NOC, 7/12/property card, POA or construction papers.</small>
            </div>
            <select value={documentType} onChange={e => setDocumentType(e.target.value)}>
              <option value="IDENTITY_PROOF">Identity proof</option>
              <option value="ADDRESS_PROOF">Address proof</option>
              <option value="PROPERTY_DOCUMENT">Property document</option>
              <option value="TITLE_DOCUMENT">Title / previous deed</option>
              <option value="TAX_RECEIPT">Property tax receipt</option>
              <option value="STAMP_DUTY_PROOF">Stamp duty / fee proof</option>
              <option value="NOC_OR_APPROVAL">NOC or approval</option>
              <option value="OTHER">Other supporting document</option>
            </select>
            <input type="file" accept=".pdf,.jpg,.jpeg,.png"
              onChange={e => setFile(e.target.files[0])} />
            {file && <div className="file-selected">Selected: {file.name} · {(file.size / 1024 / 1024).toFixed(2)} MB</div>}
            <button type="submit" disabled={busy}>{busy ? "Uploading…" : "Upload document for review"}</button>
            <p className="document-progress"><b>{readyDocumentTypesCount}/3 required categories complete</b> · Replacements create a new version and keep earlier versions in the record.</p>
            {uploadedDocuments.length > 0 && (
              <div className="uploaded-document-list">
                <div className="timeline-heading">
                  <div>
                    <h3>Uploaded documents</h3>
                    <p className="muted">Draft documents can be opened or removed before submission.</p>
                  </div>
                  <span>{uploadedDocuments.length} file{uploadedDocuments.length === 1 ? "" : "s"}</span>
                </div>
                {uploadedDocuments.map(document => (
                  <div className="uploaded-document-row" key={document.id}>
                    <div>
                      <strong>{document.fileName}</strong>
                      <small>{document.documentType.replaceAll("_", " ")} · v{document.versionNumber || 1} · {document.status}</small>
                      {document.reviewRemarks && <small>Officer note: {document.reviewRemarks}</small>}
                      {document.reviewedAt && <small>Reviewed {new Date(document.reviewedAt).toLocaleString("en-IN")}</small>}
                    </div>
                    <div className="document-row-actions">
                      <button type="button" className="secondary-button" onClick={() => openProtectedDocument(application.id, document.id)}>View</button>
                      {application.status === "DRAFT" && document.status !== "SUPERSEDED" && (
                        <button type="button" className="link-button danger-link" onClick={() => deleteDocument(document.id)} disabled={busy}>Remove</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="checklist-table">
              {requiredDocumentTypes.map(requiredType => {
                const latest = latestDocumentForType(requiredType);
                const uploaded = Boolean(latest && latest.status !== "REJECTED" && latest.status !== "SUPERSEDED");
                return <div key={requiredType} className={uploaded ? "checklist-row uploaded" : "checklist-row"}>
                  <span><b>{requiredType.replaceAll("_", " ")}</b><small>{latest ? `Latest version: v${latest.versionNumber || 1} · ${latest.status}` : "Required for demo submission"}</small></span>
                  <strong>{uploaded ? "Ready" : latest?.status === "REJECTED" ? "Correction required" : "Required"}</strong>
                </div>;
              })}
            </div>
            <div className="form-navigation">
              <button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button>
              <button type="button" className="secondary-button" onClick={() => setStep("submit")} disabled={!hasRequiredDocuments}>Continue to review</button>
            </div>
            {!hasRequiredDocuments && <p className="validation-hint">Upload all three required documents to continue: identity proof, address proof and property document.</p>}
          </form>
        )}

        {step === "submit" && (
          <div>
            <div className="form-section-heading"><span className="step-icon">06</span><div><h2>Review before submission</h2><p className="muted">Check the summary before sending the application for review.</p></div></div>
            <div className="summary">
              <p><b>Application:</b> {application?.applicationNumber}</p>
              <p><b>Property:</b> {property?.propertyNumber}</p>
              <p><b>Status:</b> {application?.status}</p>
            </div>
            <p className="muted">Required demo documents: identity proof, address proof and property document. Additional documents may be required for your transaction.</p>
            <label className="acknowledgement"><input type="checkbox" checked={submissionAcknowledged} onChange={event => setSubmissionAcknowledged(event.target.checked)} /> <span>I understand this is an academic preparation workflow, not legal approval. I will confirm the final requirements with the registering office.</span></label>
            <div className="form-navigation">
              <button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button>
              <button onClick={submitApplication} disabled={!submissionAcknowledged || !hasRequiredDocuments || busy}>Submit application for review</button>
            </div>
          </div>
        )}

        {step === "payment" && (
          <div>
            <div className="form-section-heading"><span className="step-icon">07</span><div><h2>Test-mode payment</h2><p className="muted">Demonstration payment only — no real money is charged.</p></div></div>
            <p className="muted">Complete the ₹500 test-mode demonstration fee. No real money is charged.</p>
            <div className="summary">
              <p><b>Application:</b> {application?.applicationNumber}</p>
              <p><b>Current status:</b> {application?.status}</p>
              <p><b>Amount:</b> ₹500.00</p>
            </div>
            <div className="payment-gateway-card">
              <div>
                <span className="payment-gateway-badge">RAZORPAY · TEST MODE</span>
                <h3>Secure hosted checkout</h3>
                <p>Payment details, if required, are entered inside Razorpay Checkout. PropertySetu never asks you to type card, CVV, UPI PIN, bank credentials or payment OTP into this application.</p>
              </div>
              <div className="payment-amount">₹500<span>INR</span></div>
            </div>
            <div className="decision-note payment-test-guide">
              <b>⚠️ TEST MODE ONLY — protect your real payment credentials</b>
              <span>Razorpay Test Mode is a sandbox, but the Checkout screen can still look like a normal payment page. Use only Razorpay's documented sandbox values. Never enter a real card number, CVV, UPI PIN, bank password, banking OTP or any OTP received for a real account. <b>Never use a real card just because the page displays ₹500.</b> If Checkout asks for real financial credentials or a real authentication OTP, stop and close the checkout.</span>
              <span><strong>Safest demo path:</strong> use Razorpay's Test Mode values only. If <b>UPI</b> is shown, use the documented simulated UPI value. If UPI is not shown (as it may be for this checkout), choose <b>Cards</b> and use only the official Razorpay test-card details.</span>
              <span><strong>Cards test example:</strong> Razorpay's documented domestic Mastercard test number is <code>5267 3181 8797 5449</code>. Use a future expiry and the test flow's allowed random CVV. This is dummy test data — never substitute your own card.</span>
              <span><strong>OTP safety rule:</strong> <b>never enter a real OTP.</b> A Test Mode mock Success/Failure screen is safe to use. Only enter an OTP if Razorpay's Test Mode itself explicitly provides a documented test value for that mock flow. If Checkout asks for a real banking OTP or other real financial authentication, <b>stop and close Checkout</b> — do not continue.</span>
              <span><strong>Age & personal-data rule:</strong> this is an academic demonstration. Use synthetic/demo applicant details and synthetic documents. Do not use another person's identity, card or banking credentials. A real property transaction has its own legal eligibility requirements; this website does not perform an official registration.</span>
            </div>
            <label className="acknowledgement payment-safety-check">
              <input
                type="checkbox"
                checked={paymentDemoAcknowledged}
                onChange={event => setPaymentDemoAcknowledged(event.target.checked)}
                disabled={busy}
              />
              <span><b>I understand this is a Razorpay Test Mode demonstration.</b> I will use sandbox values only and will never enter real card, CVV, UPI PIN, bank credentials or a real payment OTP.</span>
            </label>
            {!payment && <button onClick={createPayment} disabled={busy || !paymentDemoAcknowledged}>{busy ? "Opening Razorpay…" : "Open Razorpay Test Checkout"}</button>}
            {payment && payment.paymentStatus !== "SUCCESS" && (
              <div className="summary">
                <p><b>Razorpay order:</b> {payment.gatewayOrderId}</p>
                <p><b>Gateway:</b> {payment.gatewayReference || "RAZORPAY"}</p>
                <p><b>Payment status:</b> {payment.paymentStatus}</p>
                <p><b>Next:</b> Complete the Razorpay Test Mode checkout using only Razorpay's documented sandbox values. If UPI is unavailable, use the Cards test flow. If you close Checkout before a captured test payment, the record remains <b>PENDING</b>; that is expected. After a completed test payment, use “Refresh payment status” if the success callback did not return, instead of creating another order.</p>
                <div className="form-navigation">
                  <button type="button" className="secondary-button" onClick={async () => {
                    setBusy(true);
                    clearMessages();
                    const refreshed = await reconcilePaymentStatus(payment, false);
                    if (refreshed?.paymentStatus === "SUCCESS") {
                      setStep("paymentComplete");
                    } else if (refreshed) {
                      setMessage("No captured Razorpay payment was found yet. Complete the test checkout or try refreshing again.");
                    }
                    setBusy(false);
                  }} disabled={busy}>{busy ? "Checking…" : "Refresh payment status"}</button>
                  <button type="button" onClick={createPayment} disabled={busy}>{busy ? "Opening Razorpay…" : "Open Razorpay checkout again"}</button>
                </div>
              </div>
            )}
            <div className="form-navigation">
              <button type="button" className="secondary-button" onClick={goToPreviousStep}>Previous</button>
            </div>
          </div>
        )}

        {step === "paymentComplete" && (
          <div className="complete">
            <div className="check">✓</div>
            <h2>{application?.status === "RESUBMITTED" ? "Corrected documents resubmitted" : application?.status === "COMPLETED" ? "Academic workflow completed" : "Application payment recorded"}</h2>
            <p>{application?.status === "RESUBMITTED"
              ? "Your corrected documents are back with the assigned officer. Your earlier successful payment remains valid; no second application fee is due."
              : application?.status === "COMPLETED"
                ? "The assigned officer has completed the academic verification workflow. This is not an official government registration."
                : "Your test-mode payment has been confirmed. The application is available to the assigned officer for review."}</p>
            <p className="application-number">{application?.applicationNumber}</p>
            <span className="badge">{application?.status || "PAID"}</span>
            <div className="summary payment-summary">
              <p><b>Amount:</b> ₹{Number(payment?.amount || 0).toFixed(2)}</p>
              <p><b>Payment status:</b> {payment?.paymentStatus}</p>
              <p><b>Signature verified:</b> {String(payment?.signatureVerified)}</p>
              <p><b>Reference:</b> {application?.applicationNumber}</p>
            </div>
            <div className="decision-note">
              <b>Keep your application reference</b>
              <span>After signing in again, you can use Application History and Payment History above to find this record and confirm its payment status.</span>
            </div>
            <div className="form-navigation">
              <button type="button" className="secondary-button" onClick={refreshApplicantApplications}>Refresh application history</button>
            </div>
          </div>
        )}

        {step === "complete" && (
          <div className="complete">
            <div className="check">✓</div>
            <h2>Application submitted</h2>
            <p>Your application is now ready for payment.</p>
            <p className="application-number">{application?.applicationNumber}</p>
            <span className="badge">SUBMITTED</span>
          </div>
        )}
      </section>
      </main>
      <Analytics />
    </>
  );
}

export default App;